﻿// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Public License (Ms-PL).
// Please see http://go.microsoft.com/fwlink/?LinkID=131993 for details.
// All other rights reserved.

using System.Windows.Controls;

namespace BarcodeSample
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void dataText_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (!string.IsNullOrEmpty(dataText.Text))
            {
                // clamp to 14 characters to not worry about the
                // limited amount of data that QR 2 can hold
                if (dataText.Text.Length > 12)
                {
                    dataText.Text = dataText.Text.Substring(0, 12);
                    Dispatcher.BeginInvoke(() => dataText.Select(0, 0));
                }
            }
        }
    }
}