﻿// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Public License (Ms-PL).
// Please see http://go.microsoft.com/fwlink/?LinkID=131993 for details.
// All other rights reserved.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Media.Animation;
using System.Windows.Markup;
using System.Windows.Shapes;
using BarcodeEncoder = ThoughtWorks.QRCode.Codec.QRCodeEncoder;
using Silverlight.Samples;

namespace Silverlight.Barcode
{
    /// <summary>
    /// Creates a control that contains a two-dimensional barcode of the QR code
    /// type.
    /// </summary>
    [TemplatePart(Name = ImagePartName, Type = typeof(Image))]
    [ContentProperty("Text")]
    public class QuickReadBarcode : Control
    {
        /// <summary>
        /// The name of the Image template part.
        /// </summary>
        private const string ImagePartName = "Image";

        /// <summary>
        /// The image template part.
        /// </summary>
        private Image _image;

        /// <summary>
        /// The encoder instance.
        /// </summary>
        private BarcodeEncoder _encoder;

        #region public string Text
        /// <summary>
        /// Gets or sets the text to encode into the barcode.
        /// </summary>
        public string Text
        {
            get { return GetValue(TextProperty) as string; }
            set { SetValue(TextProperty, value); }
        }

        /// <summary>
        /// Identifies the Text dependency property.
        /// </summary>
        public static readonly DependencyProperty TextProperty =
            DependencyProperty.Register(
                "Text",
                typeof(string),
                typeof(QuickReadBarcode),
                new PropertyMetadata(string.Empty, OnTextPropertyChanged));

        /// <summary>
        /// TextProperty property changed handler.
        /// </summary>
        /// <param name="d">QRBarcode that changed its Text.</param>
        /// <param name="e">Event arguments.</param>
        private static void OnTextPropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            QuickReadBarcode source = d as QuickReadBarcode;
            string value = e.NewValue as string;

            if (source._image != null)
            {
                source.UpdateUnderlyingImage();
            }
        }
        #endregion public string Text

        #region public Stretch Stretch
        /// <summary>
        /// Gets or sets the Stretch property that is template bound to the
        /// image.
        /// </summary>
        public Stretch Stretch
        {
            get { return (Stretch)GetValue(StretchProperty); }
            set { SetValue(StretchProperty, value); }
        }

        /// <summary>
        /// Identifies the Stretch dependency property.
        /// </summary>
        public static readonly DependencyProperty StretchProperty =
            DependencyProperty.Register(
                "Stretch",
                typeof(Stretch),
                typeof(QuickReadBarcode),
                new PropertyMetadata(Stretch.None));

        #endregion public Stretch Stretch

        #region public Color BarcodeColor
        /// <summary>
        /// Gets or sets the barcode color.
        /// </summary>
        public Color BarcodeColor
        {
            get { return (Color)GetValue(BarcodeColorProperty); }
            set { SetValue(BarcodeColorProperty, value); }
        }

        /// <summary>
        /// Identifies the BarcodeColor dependency property.
        /// </summary>
        public static readonly DependencyProperty BarcodeColorProperty =
            DependencyProperty.Register(
                "BarcodeColor",
                typeof(Color),
                typeof(QuickReadBarcode),
                new PropertyMetadata(Colors.Black, OnBarcodeColorPropertyChanged));

        /// <summary>
        /// BarcodeColorProperty property changed handler.
        /// </summary>
        /// <param name="d">QRBarcode that changed its BarcodeColor.</param>
        /// <param name="e">Event arguments.</param>
        private static void OnBarcodeColorPropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            QuickReadBarcode source = d as QuickReadBarcode;
            Color value = (Color)e.NewValue;
        
            source.UpdateUnderlyingImage();
        }
        #endregion public Color BarcodeColor

        /// <summary>
        /// Updates the Image content.
        /// </summary>
        private void UpdateUnderlyingImage()
        {
            if (_image == null)
            {
                return;
            }

            if (_encoder == null)
            {
                _encoder = new BarcodeEncoder();

                // Version 2 is what is embedded in the file, 
                // to reduce the size of the assembly, others 
                // are not included in this control library
                // by default.
                _encoder.QRCodeVersion = 2;

                _encoder.QRCodeBackgroundColor = Colors.Transparent;
                _encoder.QRCodeForegroundColor = BarcodeColor;
            }

            EditableImage image = _encoder.Encode(Text);
            BitmapImage bitmap = new BitmapImage();
            bitmap.SetSource(image.GetStream());
            _image.Source = bitmap;
        }

        /// <summary>
        /// Initialize a new instance of the barcode control.
        /// </summary>
        public QuickReadBarcode()
        {
            DefaultStyleKey = typeof(QuickReadBarcode);
        }

        /// <summary>
        /// Called when the template changes.
        /// </summary>
        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();

            _image = GetTemplateChild(ImagePartName) as Image;

            if (_image != null && !string.IsNullOrEmpty(Text))
            {
                UpdateUnderlyingImage();
            }
        }
    }
}