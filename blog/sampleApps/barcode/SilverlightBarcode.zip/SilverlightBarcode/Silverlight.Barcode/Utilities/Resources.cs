﻿// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Public License (Ms-PL).
// Please see http://go.microsoft.com/fwlink/?LinkID=131993 for details.
// All other rights reserved.

using System;
using System.IO;
using System.Reflection;

namespace Silverlight.Samples
{
    internal static class Resources
    {
        private static Assembly _assembly;
        private static string _prefix;

        private static Stream GetResourceInternal(string filename)
        {
            if (_assembly == null)
            {
                _assembly = Assembly.GetCallingAssembly();
            }
            if (_prefix == null)
            {
                Type t = typeof(Silverlight.Barcode.QuickReadBarcode);
                _prefix = t.Namespace + ".Barcode.Resources.";
            }

            return _assembly.GetManifestResourceStream(_prefix + filename);
        }

        public static byte[] GetResource(string filename)
        {
            using (Stream stream = GetResourceInternal(filename + ".dat"))
            {
                var temp = _assembly.GetManifestResourceNames();
                if (stream == null)
                {
                    throw new InvalidOperationException("Resource could not be found.");
                }

                byte[] data = new byte[stream.Length];
                for (int i = 0; i < stream.Length; i++)
                {
                    data[i] = (byte)stream.ReadByte();
                }
                return data;
            }
        }
    }
}