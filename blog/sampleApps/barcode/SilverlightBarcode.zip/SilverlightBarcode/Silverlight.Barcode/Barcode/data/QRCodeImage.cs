using System;

// Silverlight: Color, not int
using Color = System.Windows.Media.Color;

namespace ThoughtWorks.QRCode.Codec.Data
{
	public interface QRCodeImage
	{
        int Width
        {
            get;

        }
        int Height
        {
            get;

        }
        Color getPixel(int x, int y);
	}
}