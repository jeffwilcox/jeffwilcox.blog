using System;
using System.Collections.Generic;
using System.Text;
//using Bitmap = System.Windows.Media.Imaging.WriteableBitmap;
using EditableImage = Silverlight.Samples.EditableImage;
using Bitmap = Silverlight.Samples.EditableImage;
using Color = System.Windows.Media.Color;
// Silverlight: no .NET drawing library
//using System.Drawing;

// Silverlight: adapted to use Stegman's WriteableImage

namespace ThoughtWorks.QRCode.Codec.Data
{
    public class QRCodeBitmapImage : QRCodeImage
    {
        EditableImage image; // was Bitmap

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="image">Bitmap image/param>
        public QRCodeBitmapImage(Bitmap image)
        {
            this.image = image;
        }

        virtual public int Width
        {
            get
            {
                return image.Width;
            }

        }
        virtual public int Height
        {
            get
            {
                return image.Height;
            }

        }
     

        public virtual Color getPixel(int x, int y)
        {
            // was ToArgb() as int instead of Color
            return image.GetPixel(x, y);
        }
    }
}
