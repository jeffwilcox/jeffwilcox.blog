﻿// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Public License (Ms-PL).
// Please see http://go.microsoft.com/fwlink/?LinkID=131993 for details.
// All other rights reserved.

// NOTE: This code might destroy your data. No warranty is implied. Backup your
// data. May be some of the most embarassing code ever - but it works for me!

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ThereAndBackAgain
{
    public enum VisualStudioVersion
    {
        VisualStudio2008,
        VisualStudio2010,
    }
}
