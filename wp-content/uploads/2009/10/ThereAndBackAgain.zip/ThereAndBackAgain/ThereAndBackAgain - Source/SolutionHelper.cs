﻿// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Public License (Ms-PL).
// Please see http://go.microsoft.com/fwlink/?LinkID=131993 for details.
// All other rights reserved.

// NOTE: This code might destroy your data. No warranty is implied. Backup your
// data. May be some of the most embarassing code ever - but it works for me!

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace ThereAndBackAgain
{
    /// <summary>
    /// Helper for working with raw solution files.
    /// </summary>
    public static class SolutionHelper
    {
        private const string Dev9Header = "Microsoft Visual Studio Solution File, Format Version 10.00";
        private const string Dev10Header = "Microsoft Visual Studio Solution File, Format Version 11.00";
        private const string Dev9Comment = "# Visual Studio 2008";
        private const string Dev10Comment = "# Visual Studio 2010";

        public static string ConvertFile(string path, VisualStudioVersion targetVersion)
        {
            string contents = File.ReadAllText(path);

            using (ConsoleHelper cs = new ConsoleHelper(ConsoleColor.Cyan))
            {
                cs.WriteLine("Solution " + path);
            }

            // Same as target, no change
            if (targetVersion == GetVisualStudioVersion(contents))
            {
                Console.WriteLine("No changes required.");
                return contents;
            }

            string from = targetVersion == VisualStudioVersion.VisualStudio2008 ? Dev10Header : Dev9Header;
            string to = targetVersion != VisualStudioVersion.VisualStudio2008 ? Dev10Header : Dev9Header;

            // Replace the header
            contents = contents.Replace(from, to);

            from = targetVersion == VisualStudioVersion.VisualStudio2008 ? Dev10Comment : Dev9Comment;
            to = targetVersion != VisualStudioVersion.VisualStudio2008 ? Dev10Comment : Dev9Comment;

            // Replace the comment
            contents = contents.Replace(from, to);

            return contents;
        }

        private static VisualStudioVersion GetVisualStudioVersion(string contents)
        {
            if (contents.Contains(Dev9Comment) && contents.Contains(Dev9Header))
            {
                return VisualStudioVersion.VisualStudio2008;
            }

            if (contents.Contains(Dev10Comment) && contents.Contains(Dev10Header))
            {
                return VisualStudioVersion.VisualStudio2010;
            }

            throw new InvalidOperationException("Unknown Visual Studio version.");
        }
    }
}