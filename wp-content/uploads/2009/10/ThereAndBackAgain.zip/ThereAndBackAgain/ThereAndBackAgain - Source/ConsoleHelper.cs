﻿// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Public License (Ms-PL).
// Please see http://go.microsoft.com/fwlink/?LinkID=131993 for details.
// All other rights reserved.

using System;

namespace ThereAndBackAgain
{
    /// <summary>
    /// A simple disposable console assistant type, used for maintaing the scope
    /// of a console foreground color.
    /// </summary>
    internal class ConsoleHelper : IDisposable
    {
        /// <summary>
        /// Gets or sets the initial color.
        /// </summary>
        public ConsoleColor InitialColor { get; set; }

        /// <summary>
        /// Initializes a new instance of the ConsoleHelper type.
        /// </summary>
        public ConsoleHelper()
        {
            InitialColor = Console.ForegroundColor;
        }

        /// <summary>
        /// Initializes a new instance of the ConsoleHelper type.
        /// </summary>
        /// <param name="color">The initial color to set.</param>
        public ConsoleHelper(ConsoleColor color)
            : this()
        {
            ForegroundColor = color;
        }

        /// <summary>
        /// Dispose the scope of the foreground color.
        /// </summary>
        public void Dispose()
        {
            this.Restore();
        }

        /// <summary>
        /// Restore the initial color.
        /// </summary>
        public void Restore()
        {
            Console.ForegroundColor = InitialColor;
        }

        /// <summary>
        /// Writes a new line.
        /// </summary>
        public void WriteLine()
        {
            Console.WriteLine();
        }

        /// <summary>
        /// Writes a formated line.
        /// </summary>
        /// <param name="format">The format string.</param>
        /// <param name="data">Set of parameter data for the output.</param>
        public void WriteLine(string format, params object[] data)
        {
            Console.WriteLine(format, data);
        }

        /// <summary>
        /// Writes a formated line in a specific foreground color.
        /// </summary>
        /// <param name="temporaryColor">The color to use.</param>
        /// <param name="format">The format string.</param>
        /// <param name="data">Set of parameter data for the output.</param>
        public void WriteLine(ConsoleColor temporaryColor, string format, params object[] data)
        {
            ForegroundColor = temporaryColor;
            if ((data != null) && (data.Length > 1))
            {
                Console.WriteLine(format, data);
            }
            else
            {
                Console.WriteLine(format);
            }

            Restore();
        }

        /// <summary>
        /// Set the foreground color.
        /// </summary>
        public ConsoleColor ForegroundColor
        {
            set
            {
                Console.ForegroundColor = value;
            }
        }
    }
}