﻿// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Public License (Ms-PL).
// Please see http://go.microsoft.com/fwlink/?LinkID=131993 for details.
// All other rights reserved.

// NOTE: This code might destroy your data. No warranty is implied. Backup your
// data. May be some of the most embarassing code ever - but it works for me!

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace ThereAndBackAgain
{
    class Program
    {
        static void Main(string[] args)
        {
            string path = Environment.CurrentDirectory;

            VisualStudioVersion target = VisualStudioVersion.VisualStudio2010;

            if (args.Length > 0)
            {
                if (args[0] == "2008")
                {
                    target = VisualStudioVersion.VisualStudio2008;
                }
            }

            using (ConsoleHelper ch = new ConsoleHelper(ConsoleColor.White))
            {
                ch.WriteLine(path + " will now target " + target.ToString());
            }

            DirectoryInfo di = new DirectoryInfo(path);

            var solutions = di.GetFiles("*.sln", SearchOption.AllDirectories);
            foreach (FileInfo solution in solutions)
            {
                string newContents = SolutionHelper.ConvertFile(solution.FullName, target);

                if (solution.IsReadOnly)
                {
                    solution.IsReadOnly = false;
                }
                File.WriteAllText(solution.FullName, newContents);
            }
            
            var projects = di.GetFiles("*.csproj", SearchOption.AllDirectories);
            foreach (FileInfo project in projects)
            {
                string newContents = ProjectHelper.ConvertFile(project.FullName, target);

                if (project.IsReadOnly)
                {
                    project.IsReadOnly = false;
                }
                File.WriteAllText(project.FullName, newContents);
            }

            // Delete .suo and .user files
            var userfiles = di.GetFiles("*.user", SearchOption.AllDirectories);
            foreach (var uf in userfiles)
            {
                try
                {
                    uf.Delete();
                    Console.WriteLine("Removing " + uf.FullName);
                }
                catch
                {
                }
            }
            userfiles = di.GetFiles("*.cache", SearchOption.AllDirectories);
            foreach (var uf in userfiles)
            {
                try
                {
                    uf.Delete();
                    Console.WriteLine("Removing " + uf.FullName);
                }
                catch
                {
                }
            }
            var suofiles = di.GetFiles("*.suo", SearchOption.AllDirectories);
            foreach (var sf in suofiles)
            {
                Console.WriteLine("Removing " + sf.FullName);
                sf.Delete();
            }

            using (ConsoleHelper ch = new ConsoleHelper(ConsoleColor.Green))
            {
                ch.WriteLine("Complete!");
            }
        }
    }
}