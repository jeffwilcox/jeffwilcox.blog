﻿// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Public License (Ms-PL).
// Please see http://go.microsoft.com/fwlink/?LinkID=131993 for details.
// All other rights reserved.

// NOTE: This code might destroy your data. No warranty is implied. Backup your
// data. May be some of the most embarassing code ever - but it works for me!

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace ThereAndBackAgain
{
    public static class ProjectHelper
    {
        private const string Dev9ToolsVersion = "Project ToolsVersion=\"3.5\"";
        private const string Dev10ToolsVersion = "Project ToolsVersion=\"4.0\"";
        private const string XmlHeader = @"<?xml version=""1.0"" encoding=""utf-8""?>"; // VS 2010 files have in header
        private const string Dev9ProductVersion = @"<ProductVersion>9.0.30729</ProductVersion>";
        private const string Dev10ProductVersion = @"<ProductVersion>8.0.50727</ProductVersion>";
        private const string Dev10TargetFrameworkIdentifier = @"<TargetFrameworkIdentifier>Silverlight</TargetFrameworkIdentifier>";
        private const string SilverlightVersionIdentifier = @"<SilverlightVersion>$(TargetFrameworkVersion)</SilverlightVersion>";
        private const string TargetFrameworkVersion_ForSilverlight_Dev10 = @"<TargetFrameworkVersion>v3.0</TargetFrameworkVersion>";
        private const string TargetFrameworkVersion_ForSilverlight_Dev9 = @"<TargetFrameworkVersion>v3.5</TargetFrameworkVersion>";
        private const string EndPropertyGroup = @"</PropertyGroup>";
        private const string Dev10Hack = @"  <!-- This property group is only here to support building this project using the 
       MSBuild 3.5 toolset. In order to work correctly with this older toolset, it needs 
       to set the TargetFrameworkVersion to v3.5 -->
  <PropertyGroup Condition=""'$(MSBuildToolsVersion)' == '3.5'"">
    <TargetFrameworkVersion>v3.5</TargetFrameworkVersion>
  </PropertyGroup>";

        private const string Dev9_Import_Silverlight3 = @"<Import Project=""$(MSBuildExtensionsPath32)\Microsoft\Silverlight\v3.0\Microsoft.Silverlight.CSharp.targets"" />";
        private const string Dev10_Import_Silverlight3 = @"<Import Project=""$(MSBuildExtensionsPath32)\Microsoft\Silverlight\$(SilverlightVersion)\Microsoft.Silverlight.CSharp.targets"" />";
        private const string Generator_Dev9 = @"<Generator>MSBuild:MarkupCompilePass1</Generator>";
        private const string Generator_Dev10 = @"<Generator>MSBuild:Compile</Generator>";

        public static string ConvertFile(string path, VisualStudioVersion targetVersion)
        {
            string contents = File.ReadAllText(path);

            using (ConsoleHelper cs = new ConsoleHelper(ConsoleColor.Cyan))
            {
                cs.WriteLine("Project " + path);
            }

            // Same as target, no change
            if (targetVersion == GetVisualStudioVersion(contents))
            {
                Console.WriteLine("No changes required.");
                return contents;
            }

            // 10 to 08
            if (targetVersion == VisualStudioVersion.VisualStudio2008)
            {
                using (ConsoleHelper ch = new ConsoleHelper(ConsoleColor.White))
                {
                    ch.WriteLine("Converting back to Visual Studio 2008");
                }

                contents = contents.Replace(Dev10ToolsVersion, Dev9ToolsVersion);

                // efficiency is not the name of the game in this hack
                var sep = new [] { Environment.NewLine };
                List<string> lines = new List<string>(contents.Split(sep, StringSplitOptions.None));
                if (lines.Count > 0 && lines[0].Contains(XmlHeader))
                {
                    lines.RemoveAt(0);
                    contents = string.Join(Environment.NewLine, lines.ToArray());

                    Console.WriteLine("Removed the xml declaration");
                }

                if (contents.Contains(Dev10ProductVersion))
                {
                    contents = contents.Replace(Dev10ProductVersion, Dev9ProductVersion);
                    Console.WriteLine("Updated ProductVersion element to " + Dev9ProductVersion);
                }

                lines = new List<string>(contents.Split(sep, StringSplitOptions.None));
                for (int i = 0; i < lines.Count; i++)
                {
                    string line = lines[i].Trim();
                    if (line.Contains(Dev10TargetFrameworkIdentifier))
                    {
                        Console.WriteLine("Removing TargetFrameworkIdentifier line");
                        lines.RemoveAt(i);
                        break;
                    }
                }

                for (int i = 0; i < lines.Count; i++)
                {
                    string line = lines[i].Trim();
                    if (line.Contains(SilverlightVersionIdentifier))
                    {
                        Console.WriteLine("Removing SilverlightVersion property definition line");
                        lines.RemoveAt(i);
                        break;
                    }
                }

                for (int i = 0; i < lines.Count; i++)
                {
                    string line = lines[i].Trim();
                    if (line.Contains(TargetFrameworkVersion_ForSilverlight_Dev10))
                    {
                        lines[i] = lines[i].Replace(TargetFrameworkVersion_ForSilverlight_Dev10, TargetFrameworkVersion_ForSilverlight_Dev9);
                        Console.WriteLine("Replacing target framework version used for Silverlight building.");
                        break;
                    }
                }

                contents = string.Join(Environment.NewLine, lines.ToArray());

                if (contents.Contains(Dev10Hack))
                {
                    contents = contents.Replace(Dev10Hack + Environment.NewLine, string.Empty);
                    Console.WriteLine("Removing Dev10 MSBuild hack");
                }

                if (contents.Contains(Dev10_Import_Silverlight3))
                {
                    contents = contents.Replace(Dev10_Import_Silverlight3, Dev9_Import_Silverlight3);
                    Console.WriteLine("Updating import for Silverlight");
                }

                if (contents.Contains(Generator_Dev10))
                {
                    contents = contents.Replace(Generator_Dev10, Generator_Dev9);
                    Console.WriteLine("Replacing Generator of Compile with MarkupCompilePass1 everywhere");
                }
            }

            // ---------------------------------------

            // 08 to 10
            if (targetVersion == VisualStudioVersion.VisualStudio2010)
            {
                using (ConsoleHelper ch = new ConsoleHelper(ConsoleColor.White))
                {
                    ch.WriteLine("Converting to Visual Studio 2010 awesomeness");
                }

                contents = contents.Replace(Dev9ToolsVersion, Dev10ToolsVersion);

                if (!contents.Contains(XmlHeader))
                {
                    contents = XmlHeader + Environment.NewLine + contents;
                    Console.WriteLine("Inserted the xml declaration");
                }

                if (contents.Contains(Dev9ProductVersion))
                {
                    contents = contents.Replace(Dev9ProductVersion, Dev10ProductVersion);
                    Console.WriteLine("Updated ProductVersion element to " + Dev10ProductVersion);
                }

                var sep = new[] { Environment.NewLine };
                List<string> lines = new List<string>(contents.Split(sep, StringSplitOptions.None));

                for (int i = 0; i < lines.Count; i++)
                {
                    string line = lines[i].Trim();
                    if (line.Contains(TargetFrameworkVersion_ForSilverlight_Dev9))
                    {
                        lines[i] = lines[i].Replace(TargetFrameworkVersion_ForSilverlight_Dev9, TargetFrameworkVersion_ForSilverlight_Dev10);
                        Console.WriteLine("Replacing TargetFrameworkVersion for Silverlight development.");

                        // Insert some other goods
                        lines.Insert(i, "    " + Dev10TargetFrameworkIdentifier);
                        Console.WriteLine("Inserting Dev10 TargetFrameworkIdentifier for Silverlight");

                        // order same as default project templates
                        lines.Insert(i + 2, "    " + SilverlightVersionIdentifier);
                        Console.WriteLine("Inserting SilverlightVersion identifier");

                        break;
                    }
                }
                
                for (int i = 0; i < lines.Count; i++)
                {
                    string line = lines[i].Trim();
                    // Find the first ending property group
                    if (line.Contains(EndPropertyGroup))
                    {
                        // Insert hack
                        lines.Insert(i + 1, Dev10Hack);
                        Console.WriteLine("Inserted MSBuild 3.5 toolset workaround used by Dev10");

                        break;
                    }
                }

                contents = string.Join(Environment.NewLine, lines.ToArray());

                if (contents.Contains(Dev9_Import_Silverlight3))
                {
                    contents = contents.Replace(Dev9_Import_Silverlight3, Dev10_Import_Silverlight3);
                    Console.WriteLine("Updating import for Silverlight");
                }

                if (contents.Contains(Generator_Dev9))
                {
                    contents = contents.Replace(Generator_Dev9, Generator_Dev10);
                    Console.WriteLine("Replacing Generator of MarkupCompilePass1 with Compile everywhere");
                }
            }

            return contents;
        }

        private static VisualStudioVersion GetVisualStudioVersion(string contents)
        {
            if (contents.Contains(Dev10ToolsVersion))
            {
                return VisualStudioVersion.VisualStudio2010;
            }

            if (contents.Contains(Dev9ToolsVersion))
            {
                return VisualStudioVersion.VisualStudio2008;
            }

            throw new InvalidOperationException("Unknown Visual Studio version.");
        }

    }
}