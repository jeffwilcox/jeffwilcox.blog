﻿namespace Sunali.InsertTagSnippet
{
    partial class frmSnippetProperties
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.bnCancel = new System.Windows.Forms.Button();
            this.bnSave = new System.Windows.Forms.Button();
            this.gbSuffix = new System.Windows.Forms.GroupBox();
            this.txSuffix = new System.Windows.Forms.TextBox();
            this.gbPrefix = new System.Windows.Forms.GroupBox();
            this.txPrefix = new System.Windows.Forms.TextBox();
            this.gbName = new System.Windows.Forms.GroupBox();
            this.txName = new System.Windows.Forms.TextBox();
            this.gbIsDefault = new System.Windows.Forms.GroupBox();
            this.cbIsDefault = new System.Windows.Forms.CheckBox();
            this.panel1.SuspendLayout();
            this.gbSuffix.SuspendLayout();
            this.gbPrefix.SuspendLayout();
            this.gbName.SuspendLayout();
            this.gbIsDefault.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.bnCancel);
            this.panel1.Controls.Add(this.bnSave);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 374);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(584, 30);
            this.panel1.TabIndex = 4;
            // 
            // bnCancel
            // 
            this.bnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.bnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.bnCancel.Location = new System.Drawing.Point(497, 4);
            this.bnCancel.Name = "bnCancel";
            this.bnCancel.Size = new System.Drawing.Size(75, 23);
            this.bnCancel.TabIndex = 1;
            this.bnCancel.Text = "Cancel";
            this.bnCancel.UseVisualStyleBackColor = true;
            // 
            // bnSave
            // 
            this.bnSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.bnSave.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.bnSave.Location = new System.Drawing.Point(416, 4);
            this.bnSave.Name = "bnSave";
            this.bnSave.Size = new System.Drawing.Size(75, 23);
            this.bnSave.TabIndex = 0;
            this.bnSave.Text = "Save";
            this.bnSave.UseVisualStyleBackColor = true;
            this.bnSave.Click += new System.EventHandler(this.bnSave_Click);
            // 
            // gbSuffix
            // 
            this.gbSuffix.Controls.Add(this.txSuffix);
            this.gbSuffix.Location = new System.Drawing.Point(0, 187);
            this.gbSuffix.Name = "gbSuffix";
            this.gbSuffix.Size = new System.Drawing.Size(584, 125);
            this.gbSuffix.TabIndex = 2;
            this.gbSuffix.TabStop = false;
            this.gbSuffix.Text = "Suffix";
            // 
            // txSuffix
            // 
            this.txSuffix.AcceptsReturn = true;
            this.txSuffix.AcceptsTab = true;
            this.txSuffix.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txSuffix.Location = new System.Drawing.Point(3, 16);
            this.txSuffix.Multiline = true;
            this.txSuffix.Name = "txSuffix";
            this.txSuffix.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txSuffix.Size = new System.Drawing.Size(578, 106);
            this.txSuffix.TabIndex = 0;
            this.txSuffix.WordWrap = false;
            // 
            // gbPrefix
            // 
            this.gbPrefix.Controls.Add(this.txPrefix);
            this.gbPrefix.Location = new System.Drawing.Point(0, 57);
            this.gbPrefix.Name = "gbPrefix";
            this.gbPrefix.Size = new System.Drawing.Size(584, 125);
            this.gbPrefix.TabIndex = 1;
            this.gbPrefix.TabStop = false;
            this.gbPrefix.Text = "Prefix";
            // 
            // txPrefix
            // 
            this.txPrefix.AcceptsReturn = true;
            this.txPrefix.AcceptsTab = true;
            this.txPrefix.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txPrefix.Location = new System.Drawing.Point(3, 16);
            this.txPrefix.Multiline = true;
            this.txPrefix.Name = "txPrefix";
            this.txPrefix.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txPrefix.Size = new System.Drawing.Size(578, 106);
            this.txPrefix.TabIndex = 0;
            this.txPrefix.WordWrap = false;
            // 
            // gbName
            // 
            this.gbName.Controls.Add(this.txName);
            this.gbName.Location = new System.Drawing.Point(0, 3);
            this.gbName.Name = "gbName";
            this.gbName.Size = new System.Drawing.Size(584, 50);
            this.gbName.TabIndex = 0;
            this.gbName.TabStop = false;
            this.gbName.Text = "Name";
            // 
            // txName
            // 
            this.txName.Location = new System.Drawing.Point(12, 19);
            this.txName.Name = "txName";
            this.txName.Size = new System.Drawing.Size(560, 20);
            this.txName.TabIndex = 0;
            // 
            // gbIsDefault
            // 
            this.gbIsDefault.Controls.Add(this.cbIsDefault);
            this.gbIsDefault.Location = new System.Drawing.Point(0, 317);
            this.gbIsDefault.Name = "gbIsDefault";
            this.gbIsDefault.Size = new System.Drawing.Size(584, 50);
            this.gbIsDefault.TabIndex = 3;
            this.gbIsDefault.TabStop = false;
            this.gbIsDefault.Text = "Miscellaneous";
            // 
            // cbIsDefault
            // 
            this.cbIsDefault.AutoSize = true;
            this.cbIsDefault.Location = new System.Drawing.Point(12, 19);
            this.cbIsDefault.Name = "cbIsDefault";
            this.cbIsDefault.Size = new System.Drawing.Size(128, 17);
            this.cbIsDefault.TabIndex = 0;
            this.cbIsDefault.Text = "Set as default snippet";
            this.cbIsDefault.UseVisualStyleBackColor = true;
            // 
            // frmSnippetProperties
            // 
            this.AcceptButton = this.bnSave;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.bnCancel;
            this.ClientSize = new System.Drawing.Size(584, 404);
            this.Controls.Add(this.gbIsDefault);
            this.Controls.Add(this.gbName);
            this.Controls.Add(this.gbPrefix);
            this.Controls.Add(this.gbSuffix);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmSnippetProperties";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Snippet Properties";
            this.Load += new System.EventHandler(this.frmSnippetProperties_Load);
            this.panel1.ResumeLayout(false);
            this.gbSuffix.ResumeLayout(false);
            this.gbSuffix.PerformLayout();
            this.gbPrefix.ResumeLayout(false);
            this.gbPrefix.PerformLayout();
            this.gbName.ResumeLayout(false);
            this.gbName.PerformLayout();
            this.gbIsDefault.ResumeLayout(false);
            this.gbIsDefault.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button bnCancel;
        private System.Windows.Forms.Button bnSave;
        private System.Windows.Forms.GroupBox gbSuffix;
        private System.Windows.Forms.TextBox txSuffix;
        private System.Windows.Forms.GroupBox gbPrefix;
        private System.Windows.Forms.TextBox txPrefix;
        private System.Windows.Forms.GroupBox gbName;
        private System.Windows.Forms.TextBox txName;
        private System.Windows.Forms.GroupBox gbIsDefault;
        private System.Windows.Forms.CheckBox cbIsDefault;
    }
}