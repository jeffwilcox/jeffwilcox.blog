﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Sunali.InsertTagSnippet
{
    public class SnippetEntity
    {
        private Guid m_Id;
        private bool m_IsDefault;
        private string m_Name;
        private string m_Prefix;
        private string m_Suffix;

        public Guid Id
        {
            get { return m_Id; }
            set { m_Id = value; }
        }
        public bool IsDefault
        {
            get { return m_IsDefault; }
            set { m_IsDefault = value; }
        }
        public string Name
        {
            get { return m_Name; }
            set { m_Name = value; }
        }
        public string Prefix
        {
            get { return m_Prefix; }
            set { m_Prefix = value; }
        }
        public string Suffix
        {
            get { return m_Suffix; }
            set { m_Suffix = value; }
        }

        public SnippetEntity()
        {
            Id = Guid.Empty;
            IsDefault = false;
            Name = string.Empty;
            Prefix = string.Empty;
            Suffix = string.Empty;
        }

        public SnippetEntity(string name)
        {
            Id = Guid.Empty;
            IsDefault = false;
            Name = name;
            Prefix = string.Empty;
            Suffix = string.Empty;
        }

        public SnippetEntity(Guid id, bool isDefault, string name, string prefix, string suffix)
        {
            Id = id;
            IsDefault = isDefault;
            Name = name;
            Prefix = prefix;
            Suffix = suffix;
        }
    }
}
