﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Sunali.InsertTagSnippet
{
    public partial class frmSnippetProperties : Form
    {
        private SnippetEntity m_Snippet;

        public frmSnippetProperties()
        {
            InitializeComponent();

            m_Snippet = new SnippetEntity();
        }

        public frmSnippetProperties(SnippetEntity snippet)
        {
            InitializeComponent();

            m_Snippet = snippet;
        }

        private void frmSnippetProperties_Load(object sender, EventArgs e)
        {
            if (m_Snippet != null)
            {
                txName.Text = m_Snippet.Name;
                txPrefix.Text = m_Snippet.Prefix;
                txSuffix.Text = m_Snippet.Suffix;
                cbIsDefault.Checked = m_Snippet.IsDefault;
            }
        }

        private void bnSave_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txName.Text.Trim()))
            {
                Helpers.ShowErrorDialog("Name is mandatory.");
                DialogResult = DialogResult.None;
                txName.Focus();
                return;
            }

            m_Snippet.Name = txName.Text.Trim();
            m_Snippet.Prefix = txPrefix.Text;
            m_Snippet.Suffix = txSuffix.Text;
            m_Snippet.IsDefault = cbIsDefault.Checked;

            if (m_Snippet.Id == Guid.Empty)
            {
                Guid m_NewSnippetId = DataHelper.AddSnippet(m_Snippet, true);
                if (m_NewSnippetId == Guid.Empty)
                {
                    Helpers.ShowErrorDialog("Snippet was not added for some reason.");
                    DialogResult = DialogResult.None;
                    return;
                }
            }
            else
            {
                bool m_Succeeded = DataHelper.UpdateSnippet(m_Snippet, true);
                if (!m_Succeeded)
                {
                    Helpers.ShowErrorDialog("Snippet was not updated for some reason.");
                    DialogResult = DialogResult.None;
                    return;
                }
            }
        }
    }
}
