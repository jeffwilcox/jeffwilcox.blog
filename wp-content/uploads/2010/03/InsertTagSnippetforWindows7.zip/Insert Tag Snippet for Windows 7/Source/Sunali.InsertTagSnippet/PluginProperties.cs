﻿using System;
using System.Collections.Generic;
using System.Text;
using WindowsLive.Writer.Api;

namespace Sunali.InsertTagSnippet
{
    public class PluginProperties
    {
        private IProperties m_Properties;

        public PluginProperties(IProperties properties)
        {
            m_Properties = properties;
        }

        public string Content
        {
            get { return m_Properties.GetString("Content", string.Empty); }
            set { m_Properties.SetString("Content", value); }
        }

        public Guid SnippetId
        {
            get { return new Guid(m_Properties.GetString("SnippetId", Guid.Empty.ToString())); }
            set { m_Properties.SetString("SnippetId", value.ToString()); }
        }
    }
}
