﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using WindowsLive.Writer.Api;
using System.Diagnostics;

namespace Sunali.InsertTagSnippet
{
    public partial class PluginContentEditor : SmartContentEditor
    {
        private ISmartContent m_content;
        private PluginProperties m_settings;

        public PluginContentEditor()
        {
            InitializeComponent();
            this.SelectedContentChanged += new EventHandler(PluginContentEditor_SelectedContentChanged);
        }

        void PluginContentEditor_SelectedContentChanged(object sender, EventArgs e)
        {
            this.m_content = this.SelectedContent;
            this.m_settings = new PluginProperties(this.m_content.Properties);
        }

        private void lbChangeContent_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            using (frmMain main = new frmMain(this.m_settings))
            {
                if (main.ShowDialog() == DialogResult.OK)
                {
                    this.OnContentEdited();
                }
            }
        }

        private void llbBlog_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Process.Start("http://sunali.com/?source=InsertTagSnippet");
        }
    }
}
