﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Sunali.InsertTagSnippet
{
    public partial class frmMain : Form
    {
        private PluginProperties m_Properties;

        public frmMain(PluginProperties properties)
        {
            m_Properties = properties;

            InitializeComponent();
            
            txContent.Text = properties.Content;
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            BindSnippetLists();
        }

        private void bnInsert_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txContent.Text.Trim()))
            {
                Helpers.ShowWarningDialog("Please write some content.");
                DialogResult = DialogResult.None;
                txContent.Focus();
                return;
            }

            if (cbReplaceLessGreaterThan.Checked)
            {
                m_Properties.Content = txContent.Text.Replace("<", "&lt;").Replace(">", "&gt;");
            }
            else
            {
                m_Properties.Content = txContent.Text;
            }

            if (tscbSnippetToUse.SelectedIndex > -1)
            {
                m_Properties.SnippetId = ((SnippetEntity)tscbSnippetToUse.SelectedItem).Id;
            }
            else
            {
                DialogResult = DialogResult.None;
            }
        }

        private void BindSnippetLists()
        {
            List<SnippetEntity> m_SnippetList = DataHelper.GetSnippets();

            lvSnippets.Items.Clear();
            if (m_SnippetList != null)
            {
                tscbSnippetToUse.ComboBox.DataSource = m_SnippetList;
                tscbSnippetToUse.ComboBox.DisplayMember = "Name";
                tscbSnippetToUse.ComboBox.ValueMember = "Id";

                ListViewItem m_ListViewItem;
                foreach (SnippetEntity snippet in m_SnippetList)
                {
                    m_ListViewItem = lvSnippets.Items.Add(snippet.Id.ToString());
                    m_ListViewItem.SubItems.Add(snippet.Name);
                    m_ListViewItem.SubItems.Add(snippet.IsDefault ? "Yes" : "No");

                    if (snippet.IsDefault)
                    {
                        tscbSnippetToUse.SelectedItem = snippet;
                    }
                }
            }
        }

        private void tsbAdd_Click(object sender, EventArgs e)
        {
            ShowAddSnippetDialog();
        }

        private void tsbEdit_Click(object sender, EventArgs e)
        {
            ShowEditSnippetDialog();
        }

        private void tsbDelete_Click(object sender, EventArgs e)
        {
            ShowDeleteSnippetConfirmationAndDelete();
        }

        private void lvSnippets_DoubleClick(object sender, EventArgs e)
        {
            ShowEditSnippetDialog();
        }

        private void ShowAddSnippetDialog()
        {
            using (frmSnippetProperties snippetProp = new frmSnippetProperties())
            {
                if (snippetProp.ShowDialog() == DialogResult.OK)
                {
                    BindSnippetLists();
                }
            }
        }

        private void ShowEditSnippetDialog()
        {
            if (lvSnippets.SelectedItems.Count == 0)
            {
                Helpers.ShowWarningDialog("Please select an item first.");
                return;
            }

            SnippetEntity m_Snippet = DataHelper.GetSnippetById(new Guid(lvSnippets.SelectedItems[0].Text));

            using (frmSnippetProperties snippetProp = new frmSnippetProperties(m_Snippet))
            {
                if (snippetProp.ShowDialog() == DialogResult.OK)
                {
                    BindSnippetLists();
                }
            }
        }

        private void ShowDeleteSnippetConfirmationAndDelete()
        {
            if (lvSnippets.SelectedItems.Count == 0)
            {
                Helpers.ShowWarningDialog("Please select an item first.");
                return;
            }

            SnippetEntity m_Snippet = DataHelper.GetSnippetById(new Guid(lvSnippets.SelectedItems[0].Text));

            if (Helpers.ShowConfirmationDialog(string.Format("Are you sure that you want to delete the snippet: \"{0}\"?", m_Snippet.Name)) == DialogResult.Yes)
            {
                bool m_Succeeded = DataHelper.DeleteSnippet(m_Snippet.Id, true);
                if (m_Succeeded)
                {
                    BindSnippetLists();
                }
                else
                {
                    Helpers.ShowErrorDialog("Snippet was not deleted for some reason.");
                }
            }
        }
    }
}
