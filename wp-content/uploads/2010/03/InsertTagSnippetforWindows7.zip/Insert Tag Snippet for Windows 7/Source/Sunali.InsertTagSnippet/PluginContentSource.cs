﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using WindowsLive.Writer.Api;

namespace Sunali.InsertTagSnippet
{
    [
    WriterPlugin("887EC618-8FBE-49a5-A908-2339AF2EC720", "Insert Tag Snippet", Description = "Allows you to insert your custom collection of tag snippets. eg: <code><pre>...</pre></code>.", HasEditableOptions = false, Name = "Insert Tag Snippet", PublisherUrl = "http://sunali.com/", ImagePath="code.gif")
    , 
    InsertableContentSource("Tag Snippet")
    ]
    public class PluginContentSource : SmartContentSource
    {
        public override DialogResult CreateContent(IWin32Window dialogOwner, ISmartContent newContent)
        {
            PluginProperties properties = new PluginProperties(newContent.Properties);
            using (frmMain main = new frmMain(properties))
            {
                return main.ShowDialog();
            }
        }

        public override SmartContentEditor CreateEditor(ISmartContentEditorSite editorSite)
        {
            return new PluginContentEditor();
        }


        public override string GeneratePublishHtml(ISmartContent content, IPublishingContext publishingContext)
        {
            PluginProperties properties = new PluginProperties(content.Properties);
            SnippetEntity snippet = DataHelper.GetSnippetById(properties.SnippetId);
            return string.Format("{0}{1}{2}", snippet.Prefix, properties.Content, snippet.Suffix);
        }

        public override void EditOptions(IWin32Window dialogOwner)
        {
            base.EditOptions(dialogOwner);
        }
    }
}
