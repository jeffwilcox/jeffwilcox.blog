﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace Sunali.InsertTagSnippet
{
    public static class Helpers
    {
        public static DialogResult ShowWarningDialog(string message)
        {
            return MessageBox.Show(message, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        }

        public static DialogResult ShowErrorDialog(string message)
        {
            return MessageBox.Show(message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        public static DialogResult ShowConfirmationDialog(string message)
        {
            return MessageBox.Show(message, "Are you sure?", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
        }
    }
}
