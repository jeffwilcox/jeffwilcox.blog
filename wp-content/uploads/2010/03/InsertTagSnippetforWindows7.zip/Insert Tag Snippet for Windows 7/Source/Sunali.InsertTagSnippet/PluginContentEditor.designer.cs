﻿namespace Sunali.InsertTagSnippet
{
    partial class PluginContentEditor
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbChangeContent = new System.Windows.Forms.LinkLabel();
            this.llbBlog = new System.Windows.Forms.LinkLabel();
            this.SuspendLayout();
            // 
            // lbChangeContent
            // 
            this.lbChangeContent.AutoSize = true;
            this.lbChangeContent.Location = new System.Drawing.Point(3, 14);
            this.lbChangeContent.Name = "lbChangeContent";
            this.lbChangeContent.Size = new System.Drawing.Size(83, 13);
            this.lbChangeContent.TabIndex = 0;
            this.lbChangeContent.TabStop = true;
            this.lbChangeContent.Text = "Change content";
            this.lbChangeContent.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lbChangeContent_LinkClicked);
            // 
            // llbBlog
            // 
            this.llbBlog.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.llbBlog.AutoSize = true;
            this.llbBlog.Location = new System.Drawing.Point(3, 474);
            this.llbBlog.Name = "llbBlog";
            this.llbBlog.Size = new System.Drawing.Size(85, 13);
            this.llbBlog.TabIndex = 1;
            this.llbBlog.TabStop = true;
            this.llbBlog.Text = "Coskun SUNALI";
            this.llbBlog.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llbBlog_LinkClicked);
            // 
            // PluginContentEditor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.llbBlog);
            this.Controls.Add(this.lbChangeContent);
            this.Name = "PluginContentEditor";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.LinkLabel lbChangeContent;
        private System.Windows.Forms.LinkLabel llbBlog;
    }
}
