﻿namespace Sunali.InsertTagSnippet
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.txContent = new System.Windows.Forms.TextBox();
            this.bnCancel = new System.Windows.Forms.Button();
            this.bnInsert = new System.Windows.Forms.Button();
            this.tcMain = new System.Windows.Forms.TabControl();
            this.tpContent = new System.Windows.Forms.TabPage();
            this.gbContent = new System.Windows.Forms.GroupBox();
            this.tsContent = new System.Windows.Forms.ToolStrip();
            this.tslSnippetToUse = new System.Windows.Forms.ToolStripLabel();
            this.tscbSnippetToUse = new System.Windows.Forms.ToolStripComboBox();
            this.tpSnippetsAndSettings = new System.Windows.Forms.TabPage();
            this.gbSnippets = new System.Windows.Forms.GroupBox();
            this.lvSnippets = new System.Windows.Forms.ListView();
            this.chId = new System.Windows.Forms.ColumnHeader();
            this.chName = new System.Windows.Forms.ColumnHeader();
            this.chIsDefault = new System.Windows.Forms.ColumnHeader();
            this.tsSnippetsAndSettings = new System.Windows.Forms.ToolStrip();
            this.tsbAdd = new System.Windows.Forms.ToolStripButton();
            this.tsbEdit = new System.Windows.Forms.ToolStripButton();
            this.tsbDelete = new System.Windows.Forms.ToolStripButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.cbReplaceLessGreaterThan = new System.Windows.Forms.CheckBox();
            this.tcMain.SuspendLayout();
            this.tpContent.SuspendLayout();
            this.gbContent.SuspendLayout();
            this.tsContent.SuspendLayout();
            this.tpSnippetsAndSettings.SuspendLayout();
            this.gbSnippets.SuspendLayout();
            this.tsSnippetsAndSettings.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txContent
            // 
            this.txContent.AcceptsReturn = true;
            this.txContent.AcceptsTab = true;
            this.txContent.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txContent.Location = new System.Drawing.Point(3, 16);
            this.txContent.Multiline = true;
            this.txContent.Name = "txContent";
            this.txContent.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txContent.Size = new System.Drawing.Size(604, 338);
            this.txContent.TabIndex = 0;
            this.txContent.WordWrap = false;
            // 
            // bnCancel
            // 
            this.bnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.bnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.bnCancel.Location = new System.Drawing.Point(537, 4);
            this.bnCancel.Name = "bnCancel";
            this.bnCancel.Size = new System.Drawing.Size(75, 23);
            this.bnCancel.TabIndex = 1;
            this.bnCancel.Text = "Cancel";
            this.bnCancel.UseVisualStyleBackColor = true;
            // 
            // bnInsert
            // 
            this.bnInsert.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.bnInsert.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.bnInsert.Location = new System.Drawing.Point(456, 4);
            this.bnInsert.Name = "bnInsert";
            this.bnInsert.Size = new System.Drawing.Size(75, 23);
            this.bnInsert.TabIndex = 0;
            this.bnInsert.Text = "Insert";
            this.bnInsert.UseVisualStyleBackColor = true;
            this.bnInsert.Click += new System.EventHandler(this.bnInsert_Click);
            // 
            // tcMain
            // 
            this.tcMain.Controls.Add(this.tpContent);
            this.tcMain.Controls.Add(this.tpSnippetsAndSettings);
            this.tcMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tcMain.Location = new System.Drawing.Point(0, 0);
            this.tcMain.Name = "tcMain";
            this.tcMain.SelectedIndex = 0;
            this.tcMain.Size = new System.Drawing.Size(624, 414);
            this.tcMain.TabIndex = 0;
            // 
            // tpContent
            // 
            this.tpContent.Controls.Add(this.gbContent);
            this.tpContent.Controls.Add(this.cbReplaceLessGreaterThan);
            this.tpContent.Controls.Add(this.tsContent);
            this.tpContent.Location = new System.Drawing.Point(4, 22);
            this.tpContent.Name = "tpContent";
            this.tpContent.Padding = new System.Windows.Forms.Padding(3);
            this.tpContent.Size = new System.Drawing.Size(616, 388);
            this.tpContent.TabIndex = 0;
            this.tpContent.Text = "Content";
            this.tpContent.UseVisualStyleBackColor = true;
            // 
            // gbContent
            // 
            this.gbContent.Controls.Add(this.txContent);
            this.gbContent.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gbContent.Location = new System.Drawing.Point(3, 28);
            this.gbContent.Name = "gbContent";
            this.gbContent.Size = new System.Drawing.Size(610, 357);
            this.gbContent.TabIndex = 2;
            this.gbContent.TabStop = false;
            this.gbContent.Text = "HTML content to insert between the tag snippet:";
            // 
            // tsContent
            // 
            this.tsContent.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tslSnippetToUse,
            this.tscbSnippetToUse});
            this.tsContent.Location = new System.Drawing.Point(3, 3);
            this.tsContent.Name = "tsContent";
            this.tsContent.Size = new System.Drawing.Size(610, 25);
            this.tsContent.TabIndex = 0;
            // 
            // tslSnippetToUse
            // 
            this.tslSnippetToUse.Name = "tslSnippetToUse";
            this.tslSnippetToUse.Size = new System.Drawing.Size(85, 22);
            this.tslSnippetToUse.Text = "Snippet to use:";
            // 
            // tscbSnippetToUse
            // 
            this.tscbSnippetToUse.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.tscbSnippetToUse.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.tscbSnippetToUse.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.tscbSnippetToUse.Name = "tscbSnippetToUse";
            this.tscbSnippetToUse.Size = new System.Drawing.Size(250, 25);
            // 
            // tpSnippetsAndSettings
            // 
            this.tpSnippetsAndSettings.Controls.Add(this.gbSnippets);
            this.tpSnippetsAndSettings.Controls.Add(this.tsSnippetsAndSettings);
            this.tpSnippetsAndSettings.Location = new System.Drawing.Point(4, 22);
            this.tpSnippetsAndSettings.Name = "tpSnippetsAndSettings";
            this.tpSnippetsAndSettings.Padding = new System.Windows.Forms.Padding(3);
            this.tpSnippetsAndSettings.Size = new System.Drawing.Size(616, 388);
            this.tpSnippetsAndSettings.TabIndex = 1;
            this.tpSnippetsAndSettings.Text = "Snippets & Settings";
            this.tpSnippetsAndSettings.UseVisualStyleBackColor = true;
            // 
            // gbSnippets
            // 
            this.gbSnippets.Controls.Add(this.lvSnippets);
            this.gbSnippets.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gbSnippets.Location = new System.Drawing.Point(3, 28);
            this.gbSnippets.Name = "gbSnippets";
            this.gbSnippets.Size = new System.Drawing.Size(610, 357);
            this.gbSnippets.TabIndex = 1;
            this.gbSnippets.TabStop = false;
            this.gbSnippets.Text = "Snippets";
            // 
            // lvSnippets
            // 
            this.lvSnippets.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.chId,
            this.chName,
            this.chIsDefault});
            this.lvSnippets.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lvSnippets.FullRowSelect = true;
            this.lvSnippets.GridLines = true;
            this.lvSnippets.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.lvSnippets.Location = new System.Drawing.Point(3, 16);
            this.lvSnippets.MultiSelect = false;
            this.lvSnippets.Name = "lvSnippets";
            this.lvSnippets.Size = new System.Drawing.Size(604, 338);
            this.lvSnippets.TabIndex = 0;
            this.lvSnippets.UseCompatibleStateImageBehavior = false;
            this.lvSnippets.View = System.Windows.Forms.View.Details;
            this.lvSnippets.DoubleClick += new System.EventHandler(this.lvSnippets_DoubleClick);
            // 
            // chId
            // 
            this.chId.Width = 0;
            // 
            // chName
            // 
            this.chName.Text = "Name";
            this.chName.Width = 500;
            // 
            // chIsDefault
            // 
            this.chIsDefault.Text = "Is Default?";
            this.chIsDefault.Width = 75;
            // 
            // tsSnippetsAndSettings
            // 
            this.tsSnippetsAndSettings.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbAdd,
            this.tsbEdit,
            this.tsbDelete});
            this.tsSnippetsAndSettings.Location = new System.Drawing.Point(3, 3);
            this.tsSnippetsAndSettings.Name = "tsSnippetsAndSettings";
            this.tsSnippetsAndSettings.Size = new System.Drawing.Size(610, 25);
            this.tsSnippetsAndSettings.TabIndex = 0;
            this.tsSnippetsAndSettings.Text = "toolStrip1";
            // 
            // tsbAdd
            // 
            this.tsbAdd.Image = ((System.Drawing.Image)(resources.GetObject("tsbAdd.Image")));
            this.tsbAdd.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbAdd.Name = "tsbAdd";
            this.tsbAdd.Size = new System.Drawing.Size(49, 22);
            this.tsbAdd.Text = "Add";
            this.tsbAdd.Click += new System.EventHandler(this.tsbAdd_Click);
            // 
            // tsbEdit
            // 
            this.tsbEdit.Image = ((System.Drawing.Image)(resources.GetObject("tsbEdit.Image")));
            this.tsbEdit.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbEdit.Name = "tsbEdit";
            this.tsbEdit.Size = new System.Drawing.Size(47, 22);
            this.tsbEdit.Text = "Edit";
            this.tsbEdit.Click += new System.EventHandler(this.tsbEdit_Click);
            // 
            // tsbDelete
            // 
            this.tsbDelete.Image = ((System.Drawing.Image)(resources.GetObject("tsbDelete.Image")));
            this.tsbDelete.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbDelete.Name = "tsbDelete";
            this.tsbDelete.Size = new System.Drawing.Size(60, 22);
            this.tsbDelete.Text = "Delete";
            this.tsbDelete.Click += new System.EventHandler(this.tsbDelete_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.bnCancel);
            this.panel1.Controls.Add(this.bnInsert);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 414);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(624, 30);
            this.panel1.TabIndex = 1;
            // 
            // cbReplaceLessGreaterThan
            // 
            this.cbReplaceLessGreaterThan.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cbReplaceLessGreaterThan.AutoSize = true;
            this.cbReplaceLessGreaterThan.BackColor = System.Drawing.SystemColors.MenuBar;
            this.cbReplaceLessGreaterThan.Location = new System.Drawing.Point(399, 5);
            this.cbReplaceLessGreaterThan.Name = "cbReplaceLessGreaterThan";
            this.cbReplaceLessGreaterThan.Size = new System.Drawing.Size(209, 17);
            this.cbReplaceLessGreaterThan.TabIndex = 1;
            this.cbReplaceLessGreaterThan.Text = "Replace < and > tags with &&lt; and &&gt;";
            this.cbReplaceLessGreaterThan.UseVisualStyleBackColor = false;
            // 
            // frmMain
            // 
            this.AcceptButton = this.bnInsert;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.bnCancel;
            this.ClientSize = new System.Drawing.Size(624, 444);
            this.Controls.Add(this.tcMain);
            this.Controls.Add(this.panel1);
            this.Name = "frmMain";
            this.Text = "Insert Tag Snippet";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.tcMain.ResumeLayout(false);
            this.tpContent.ResumeLayout(false);
            this.tpContent.PerformLayout();
            this.gbContent.ResumeLayout(false);
            this.gbContent.PerformLayout();
            this.tsContent.ResumeLayout(false);
            this.tsContent.PerformLayout();
            this.tpSnippetsAndSettings.ResumeLayout(false);
            this.tpSnippetsAndSettings.PerformLayout();
            this.gbSnippets.ResumeLayout(false);
            this.tsSnippetsAndSettings.ResumeLayout(false);
            this.tsSnippetsAndSettings.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox txContent;
        private System.Windows.Forms.Button bnCancel;
        private System.Windows.Forms.Button bnInsert;
        private System.Windows.Forms.TabControl tcMain;
        private System.Windows.Forms.TabPage tpContent;
        private System.Windows.Forms.TabPage tpSnippetsAndSettings;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ListView lvSnippets;
        private System.Windows.Forms.ColumnHeader chName;
        private System.Windows.Forms.ColumnHeader chIsDefault;
        private System.Windows.Forms.ToolStrip tsSnippetsAndSettings;
        private System.Windows.Forms.ToolStripButton tsbAdd;
        private System.Windows.Forms.ToolStripButton tsbEdit;
        private System.Windows.Forms.ToolStripButton tsbDelete;
        private System.Windows.Forms.ToolStrip tsContent;
        private System.Windows.Forms.ToolStripLabel tslSnippetToUse;
        private System.Windows.Forms.ToolStripComboBox tscbSnippetToUse;
        private System.Windows.Forms.GroupBox gbContent;
        private System.Windows.Forms.GroupBox gbSnippets;
        private System.Windows.Forms.ColumnHeader chId;
        private System.Windows.Forms.CheckBox cbReplaceLessGreaterThan;
    }
}