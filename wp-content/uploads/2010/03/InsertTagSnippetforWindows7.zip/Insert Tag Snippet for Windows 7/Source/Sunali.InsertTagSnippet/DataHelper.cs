﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.IO;

namespace Sunali.InsertTagSnippet
{
    public static class DataHelper
    {
        static XmlDocument m_DataFile;
        static bool m_IsValidDataFile;
        static readonly string m_DataFileFullName;
        static DataHelper()
        {
            m_IsValidDataFile = false;

            string appDataPath = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);

            string dir = Path.Combine(
                appDataPath,
                "Windows Live Writer");
            if (!Directory.Exists(dir))
            {
                Directory.CreateDirectory(dir);
            }
            dir = Path.Combine(dir, "Plugins");
            if (!Directory.Exists(dir))
            {
                Directory.CreateDirectory(dir);
            }

            m_DataFileFullName = Path.Combine(dir, "Sunali.InsertTagSnippet.xml");
            string originalFilename = string.Format(@"{0}\Plugins\Sunali.InsertTagSnippet.xml", Environment.CurrentDirectory);

            if (File.Exists(m_DataFileFullName))
            {
                m_IsValidDataFile = true;
            }
            else
            {
                try
                {
                    if (File.Exists(originalFilename))
                    {
                        string original = File.ReadAllText(originalFilename);
                        File.WriteAllText(m_DataFileFullName, original);
                        if (File.Exists(m_DataFileFullName))
                        {
                            m_IsValidDataFile = true;
                        }
                    }
                    else
                    {
                        XmlWriter m_DataFileXmlWriter = XmlWriter.Create(m_DataFileFullName);
                        m_DataFileXmlWriter.WriteStartDocument();
                        m_DataFileXmlWriter.WriteStartElement("snippets");
                        m_DataFileXmlWriter.WriteEndElement();
                        m_DataFileXmlWriter.Flush();
                        m_DataFileXmlWriter.Close();
                    }

                    m_IsValidDataFile = true;
                }
                catch (Exception)
                {
                    m_IsValidDataFile = false;
                    // we don't log to the users harddrive...
                }
            }

            if (m_IsValidDataFile)
            {
                try
                {
                    m_DataFile = new XmlDocument();
                    m_DataFile.Load(m_DataFileFullName);
                }
                catch (Exception)
                {
                    m_IsValidDataFile = false;
                    // we don't log to the users harddrive...
                }
            }
        }

        public static bool IsValidDataFile
        {
            get { return m_IsValidDataFile; }
        }

        public static SnippetEntity GetSnippetById(Guid id)
        {
            if (!IsValidDataFile)
            {
                return null;
            }

            XmlNode m_SnippetNode = m_DataFile.SelectSingleNode(string.Format("/snippets/snippet[@id='{0}']", id));

            if (m_SnippetNode != null)
            {
                try
                {
                    return new SnippetEntity(
                        id,
                        Convert.ToBoolean(m_SnippetNode.Attributes["isdefault"].Value),
                        m_SnippetNode["name"].InnerText,
                        m_SnippetNode["prefix"].InnerText,
                        m_SnippetNode["suffix"].InnerText
                        );
                }
                catch (Exception)
                {
                    return null;
                    // we don't log to the users harddrive...
                }
            }
            else
            {
                return null;
                // we don't log to the users harddrive...
            }
        }

        public static SnippetEntity GetDefaultSnippet()
        {
            if (!IsValidDataFile)
            {
                return null;
            }

            XmlNode m_SnippetNode = m_DataFile.SelectSingleNode("/snippets/snippet[@isdefault='true']");

            if (m_SnippetNode != null)
            {
                try
                {
                    return new SnippetEntity(
                        new Guid(m_SnippetNode.Attributes["id"].Value),
                        true,
                        m_SnippetNode["name"].InnerText,
                        m_SnippetNode["prefix"].InnerText,
                        m_SnippetNode["suffix"].InnerText
                        );
                }
                catch (Exception)
                {
                    return null;
                    // we don't log to the users harddrive...
                }
            }
            else
            {
                return null;
                // we don't log to the users harddrive...
            }
        }

        public static List<SnippetEntity> GetSnippets()
        {
            if (!IsValidDataFile)
            {
                return null;
            }

            XmlNodeList m_SnippetNodeList = m_DataFile.SelectNodes("/snippets/snippet");
            List<SnippetEntity> m_ResultList = new List<SnippetEntity>(m_SnippetNodeList.Count);

            foreach (XmlNode m_SnippetNode in m_SnippetNodeList)
            {
                try
                {
                    m_ResultList.Add(
                        new SnippetEntity(
                            new Guid(m_SnippetNode.Attributes["id"].Value),
                            Convert.ToBoolean(m_SnippetNode.Attributes["isdefault"].Value),
                            m_SnippetNode["name"].InnerText,
                            m_SnippetNode["prefix"].InnerText,
                            m_SnippetNode["suffix"].InnerText
                            )
                        );
                }
                catch (Exception)
                {
                    // we don't log to the users harddrive...
                }
            }

            return m_ResultList;
        }

        public static Guid AddSnippet(SnippetEntity snippet, bool autoSaveDataFile)
        {
            if (!IsValidDataFile)
            {
                return Guid.Empty;
            }

            Guid m_NewSnippetId = Guid.Empty;
            XmlNode m_SnippetsNode = m_DataFile.SelectSingleNode("/snippets");

            if (m_SnippetsNode != null)
            {
                try
                {
                    m_NewSnippetId = Guid.NewGuid();
                    XmlNode m_NewSnippetNode = m_DataFile.CreateNode(XmlNodeType.Element, "snippet", string.Empty);

                    XmlAttribute m_IdAttribute = m_DataFile.CreateAttribute("id");
                    m_IdAttribute.Value = m_NewSnippetId.ToString();
                    m_NewSnippetNode.Attributes.Append(m_IdAttribute);

                    XmlAttribute m_IsDefaultAttribute = m_DataFile.CreateAttribute("isdefault");
                    m_IsDefaultAttribute.Value = snippet.IsDefault.ToString().ToLower();
                    m_NewSnippetNode.Attributes.Append(m_IsDefaultAttribute);

                    XmlElement m_NameElement = m_DataFile.CreateElement("name");
                    m_NameElement.InnerXml = string.Format("<![CDATA[{0}]]>", snippet.Name);
                    m_NewSnippetNode.AppendChild(m_NameElement);

                    XmlElement m_PrefixElement = m_DataFile.CreateElement("prefix");
                    m_PrefixElement.InnerXml = string.Format("<![CDATA[{0}]]>", snippet.Prefix);
                    m_NewSnippetNode.AppendChild(m_PrefixElement);

                    XmlElement m_SuffixElement = m_DataFile.CreateElement("suffix");
                    m_SuffixElement.InnerXml = string.Format("<![CDATA[{0}]]>", snippet.Suffix);
                    m_NewSnippetNode.AppendChild(m_SuffixElement);

                    // we have to set the previous default node to not-default.
                    if (snippet.IsDefault)
                    {
                        SnippetEntity m_DefaultSnippet = GetDefaultSnippet();
                        if (m_DefaultSnippet != null && !snippet.Id.Equals(m_DefaultSnippet.Id))
                        {
                            m_DefaultSnippet.IsDefault = false;
                            UpdateSnippet(m_DefaultSnippet, false);
                        }
                    }

                    m_SnippetsNode.AppendChild(m_NewSnippetNode);

                    if (autoSaveDataFile)
                    {
                        m_DataFile.Save(m_DataFileFullName);
                    }

                }
                catch (Exception)
                {
                    m_NewSnippetId = Guid.Empty;
                    // we don't log to the users harddrive...
                }
            }
            else
            {
                m_NewSnippetId = Guid.Empty;
                // we don't log to the users harddrive...
            }

            return m_NewSnippetId;
        }

        public static bool UpdateSnippet(SnippetEntity snippet, bool autoSaveDataFile)
        {
            if (!IsValidDataFile)
            {
                return false;
            }

            bool m_Succeeded = false;
            XmlNode m_SnippetNode = m_DataFile.SelectSingleNode(string.Format("/snippets/snippet[@id='{0}']", snippet.Id));

            if (m_SnippetNode != null)
            {
                try
                {
                    m_SnippetNode["name"].InnerXml = string.Format("<![CDATA[{0}]]>", snippet.Name);
                    m_SnippetNode["prefix"].InnerXml = string.Format("<![CDATA[{0}]]>", snippet.Prefix);
                    m_SnippetNode["suffix"].InnerXml = string.Format("<![CDATA[{0}]]>", snippet.Suffix);

                    // we have to set the previous default node to not-default.
                    if (snippet.IsDefault)
                    {
                        SnippetEntity m_DefaultSnippet = GetDefaultSnippet();
                        if (m_DefaultSnippet != null && !snippet.Id.Equals(m_DefaultSnippet.Id))
                        {
                            m_DefaultSnippet.IsDefault = false;
                            UpdateSnippet(m_DefaultSnippet, false);
                        }
                    }

                    m_SnippetNode.Attributes["isdefault"].Value = snippet.IsDefault.ToString().ToLower();

                    if (autoSaveDataFile)
                    {
                        m_DataFile.Save(m_DataFileFullName);
                    }

                    m_Succeeded = true;
                }
                catch (Exception)
                {
                    m_Succeeded = false;
                    // we don't log to the users harddrive...
                }
            }
            else
            {
                m_Succeeded = false;
                // we don't log to the users harddrive...
            }

            return m_Succeeded;
        }

        public static bool DeleteSnippet(Guid id, bool autoSaveDataFile)
        {
            if (!IsValidDataFile)
            {
                return false;
            }

            bool m_Succeeded = false;

            XmlNode m_SnippetsNode = m_DataFile.SelectSingleNode("/snippets");
            if (m_SnippetsNode != null)
            {
                XmlNode m_SnippetNode = m_DataFile.SelectSingleNode(string.Format("/snippets/snippet[@id='{0}']", id));
                if (m_SnippetNode != null)
                {

                    try
                    {
                        m_SnippetsNode.RemoveChild(m_SnippetNode);

                        if (autoSaveDataFile)
                        {
                            m_DataFile.Save(m_DataFileFullName);
                        }

                        m_Succeeded = true;
                    }
                    catch (Exception)
                    {
                        m_Succeeded = false;
                        // we don't log to the users harddrive...
                    }
                }
                else
                {
                    m_Succeeded = false;
                    // we don't log to the users harddrive...
                }
            }
            else
            {
                m_Succeeded = false;
                // we don't log to the users harddrive...
            }

            return m_Succeeded;
        }
    }
}