﻿// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Public License (Ms-PL).
// Please see http://go.microsoft.com/fwlink/?LinkID=131993 for details.
// All other rights reserved.

using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using Peppermint.Data;

namespace Peppermint.Tests
{
    [TestClass, Ignore]
    public class CreditTests
    {
        private CreditAccount _account;

        [TestInitialize]
        public void Initialize()
        {
            _account = new CreditAccount();
        }

        [TestMethod]
        [Description("This is a test that sets the limit on the account to one thousand bucks.")]
        public void VerifySetLimit1000()
        {
            _account.Limit = 1000;
        }

        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        [TestMethod]
        public void VerifyCannotSetNegative()
        {
            _account.Limit = -500;
        }
    }
}