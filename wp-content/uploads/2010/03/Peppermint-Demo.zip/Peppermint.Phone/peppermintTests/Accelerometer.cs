﻿// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Public License (Ms-PL).
// Please see http://go.microsoft.com/fwlink/?LinkID=131993 for details.
// All other rights reserved.

using System;
using System.Windows.Media;
using Microsoft.Devices.Sensors;
using Microsoft.Silverlight.Testing;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Peppermint.PhoneTests
{
    [TestClass]
    public class Accelerometer : SilverlightTest
    {
        [TestMethod]
        [Asynchronous]
        public void BackgroundChangeOnFlat()
        {
            WrappedAccelerometerSensor.IsTesting = true;

            var page = new PhonePeppermint.MainPage();
            bool loaded = false;
            page.Loaded += (x, xe) => loaded = true;
            TestPanel.Children.Add(page);
            EnqueueConditional(() => loaded);
            EnqueueCallback(() => { WrappedAccelerometerSensor.GetAccelerometerSensor().FireReading(0, 0, .99); });
            EnqueueDelay(TimeSpan.FromSeconds(1));

            EnqueueCallback(() => Assert.AreEqual(
                Colors.Blue,
                GetColor(page.Background)));

            EnqueueTestComplete();
        }

        private Color GetColor(Brush b)
        {
            SolidColorBrush scb = b as SolidColorBrush;
            if (scb != null)
            {
                return scb.Color;
            }

            throw new InvalidOperationException("Not a SolidColorBrush.");
        }
    }
}