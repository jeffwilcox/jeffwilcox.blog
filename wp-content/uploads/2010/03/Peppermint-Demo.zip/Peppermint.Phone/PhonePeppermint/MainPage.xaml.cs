﻿// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Public License (Ms-PL).
// Please see http://go.microsoft.com/fwlink/?LinkID=131993 for details.
// All other rights reserved.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Microsoft.Devices.Sensors;
using Microsoft.Phone.Controls;

namespace PhonePeppermint
{
    public partial class MainPage : PhoneApplicationPage
    {
        /// <summary>
        /// Backing field for an Accelerometer sensor instance.
        /// </summary>
        private WrappedAccelerometerSensor _accelerometer;

        public MainPage()
        {
            InitializeComponent();

            SupportedOrientations = SupportedPageOrientation.Portrait | SupportedPageOrientation.Landscape;

            _accelerometer = WrappedAccelerometerSensor.GetAccelerometerSensor();
            _accelerometer.ReadingChanged += OnAccelerometerReadingChanged;
            _accelerometer.Start();
        }

        private void OnAccelerometerReadingChanged(object sender, WrappedAccelerometerReadingAsyncEventArgs e)
        {
            var value = e.Value.Value;

            // Is the device laying down flat?
            if (Math.Abs(value.Z) >= .96)
            {
                Dispatcher.BeginInvoke(() => Background = new SolidColorBrush(Colors.Blue));
            }
        }
    }
}