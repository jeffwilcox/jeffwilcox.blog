﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Devices.Sensors;
using System.Collections.Generic;
using System.ComponentModel;

namespace Microsoft.Devices.Sensors
{
    public class WrappedAccelerometerReading
    {
        public WrappedAccelerometerReading(double x, double y, double z)
        {
            _values = new double[] { x, y, z };
        }

        private WrappedAccelerometerReading()
        {
        }

        public WrappedAccelerometerReading(AccelerometerReading reading)
        {
            _values = new double[] { reading.X, reading.Y, reading.Z };
        }

        private double[] _values;

        public double X { get { return _values[0]; } }
        public double Y { get { return _values[1]; } }
        public double Z { get { return _values[2]; } }
    }

    public class WrappedAccelerometerReadingAsyncEventArgs : EventArgs
    {
        public WrappedAccelerometerReadingAsyncEventArgs(WrappedAccelerometerReading reading)
        {
            Value = new SensorData<WrappedAccelerometerReading>(DateTimeOffset.Now, reading);
        }

        public SensorData<WrappedAccelerometerReading> Value { get; private set;  }
    }

    public class WrappedAccelerometerSensor
    {
        public event EventHandler<WrappedAccelerometerReadingAsyncEventArgs> ReadingChanged;

        protected virtual void OnReadingChanged(WrappedAccelerometerReadingAsyncEventArgs e)
        {
            var handler = ReadingChanged;
            if (handler != null)
            {
                handler(this, e);
            }
        }

        private AccelerometerSensor _sensor;

        private static WrappedAccelerometerSensor _instance;
        
        private static bool _testing;
        
        public static bool IsTesting
        {
            get { return _testing; }
            set
            {
                bool old = _testing;
                _testing = value;
                if (old != value)
                {
                    _instance = null;
                }
            }
        }

        public static WrappedAccelerometerSensor GetAccelerometerSensor()
        {
            if (_instance == null)
            {
                _instance = new WrappedAccelerometerSensor();
                if (!_testing)
                {
                    _instance._sensor = AccelerometerSensor.Default;
                }
            }
            return _instance;
        }

        public WrappedAccelerometerSensor() { }

        private bool _isStarted;

        public void Start()
        {
            _isStarted = true;
            if (_sensor != null)
            {
                _sensor.ReadingChanged += OnPhysicalSensorReadingChanged;
                _sensor.Start();
            }
        }

        void OnPhysicalSensorReadingChanged(object sender, AccelerometerReadingAsyncEventArgs e)
        {
            OnReadingChanged(
                new WrappedAccelerometerReadingAsyncEventArgs(
                    new WrappedAccelerometerReading(
                        e.Value.Value)));
        }

        public void FireReading(double x, double y, double z)
        {
            if (!_isStarted)
            {
                throw new InvalidOperationException("The sensor is not started.");
            }
            if (!WrappedAccelerometerSensor.IsTesting)
            {
                throw new InvalidOperationException("Readings can only be fired in test mode.");
            }
            FireReadings(new WrappedAccelerometerReading[] { new WrappedAccelerometerReading(x, y, z) } );
        }

        public void FireReadings(IEnumerable<WrappedAccelerometerReading> readings)
        {
            BackgroundWorker bw = new BackgroundWorker();
            bw.DoWork += OnDoBackgroundWork;
            bw.RunWorkerAsync(readings);
        }

        private void OnDoBackgroundWork(object sender, DoWorkEventArgs e)
        {
            IEnumerable<WrappedAccelerometerReading> readings = (IEnumerable<WrappedAccelerometerReading>)e.Argument;
            foreach (WrappedAccelerometerReading reading in readings)
            {
                OnReadingChanged(new WrappedAccelerometerReadingAsyncEventArgs(reading));
            }
        }

        public void Stop()
        {
            _isStarted = false;
        }
    }
}