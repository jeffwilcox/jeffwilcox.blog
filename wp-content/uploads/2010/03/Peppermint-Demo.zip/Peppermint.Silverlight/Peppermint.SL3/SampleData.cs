﻿// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Public License (Ms-PL).
// Please see http://go.microsoft.com/fwlink/?LinkID=131993 for details.
// All other rights reserved.

namespace Peppermint.Data
{
    public class SampleData
    {
        private User _user;

        public SampleData()
        {
            _user = new User("Happy User", "user@someaddress.com");
            _user.AddAccount(
                new CreditAccount(
                    "American Express Blue", 
                    CreditBrand.AmericanExpress)
                {
                    Limit = 8000,
                    Balance = 0,
                });
            _user.AddAccount(
                new CreditAccount(
                    "Amazon.com Visa",
                    CreditBrand.Visa)
                {
                    Limit = 5000,
                    Balance = -390.49,
                });
            _user.AddAccount(
                new BankAccount(
                    "Bank of America"
                    )
                    {
                        Balance = 18500,
                    });

        }

        public User User { get { return _user; } }
    }
}