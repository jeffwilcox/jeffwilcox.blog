﻿// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Public License (Ms-PL).
// Please see http://go.microsoft.com/fwlink/?LinkID=131993 for details.
// All other rights reserved.

using System;
using Peppermint;

namespace Peppermint.Data
{
    public class Account : PropertyChangedBase
    {
        private User _accountOwner;
        private string _name;
        private double _balance;

        public event EventHandler BalanceChanged;
        public event EventHandler NameChanged;

        public Account()
        {
        }

        public Account(string name)
            : this()
        {
            _name = name;
        }

        internal User AccountOwner
        {
            get { return _accountOwner; }
            set
            {
                // Permit assigning (but not changing), plus clearing
                if (_accountOwner == null || value == null)
                {
                    _accountOwner = value;
                }
                else
                {
                    throw new NotImplementedException("Account ownership cannot change.");
                }
            }
        }

        protected virtual void OnBalanceChanged(EventArgs e)
        {
            EventHandler handler = BalanceChanged;
            if (handler != null)
            {
                handler(this, e);
            }

            NotifyPropertyChanged("Balance");
        }

        public double Balance
        {
            get { return _balance; }
            set
            {
                _balance = value;
                OnBalanceChanged(EventArgs.Empty);
            }
        }

        public string Name
        {
            get { return _name; }
            set
            {
                if (null == value)
                {
                    throw new ArgumentException("Name");
                }

                _name = value;
                OnNameChanged(EventArgs.Empty);
            }
        }

        protected virtual void OnNameChanged(EventArgs e)
        {
            EventHandler handler = NameChanged;
            if (handler != null)
            {
                handler(this, e);
            }

            NotifyPropertyChanged("Name");
        }
    }
}