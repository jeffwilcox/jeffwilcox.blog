﻿// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Public License (Ms-PL).
// Please see http://go.microsoft.com/fwlink/?LinkID=131993 for details.
// All other rights reserved.

using System;
using System.Collections.ObjectModel;
using System.Collections.Generic;
using System.Linq;

namespace Peppermint.Data
{
    public class User : PropertyChangedBase
    {
        private string _name;
        private string _email;
        private ObservableCollection<Account> _accounts;
        private double _assets;
        private double _debts;

        public event EventHandler NetWorthChanged;

        public User()
        {
            _accounts = new ObservableCollection<Account>();
        }

        public User(string name, string email)
            : this()
        {
            _name = name;
            _email = email;
        }

        public void AddAccount(Account account)
        {
            _accounts.Add(account);
            account.AccountOwner = this;
            account.BalanceChanged += OnBalanceChanged;
            if (account.Balance != 0)
            {
                RecalculateNetWorth();
            }
        }

        public void RemoveAccount(Account account)
        {
            if (!_accounts.Contains(account))
            {
                throw new InvalidOperationException("The account is not present in the user's accounts list.");
            }

            _accounts.Remove(account);
            account.BalanceChanged -= OnBalanceChanged;
            account.AccountOwner = null;

            if (account.Balance != 0)
            {
                RecalculateNetWorth();
            }
        }

        public ReadOnlyObservableCollection<Account> Accounts
        {
            get { return new ReadOnlyObservableCollection<Account>(_accounts); }
        }

        public IEnumerable<CreditAccount> CreditAccounts
        {
            get { return Accounts.OfType<CreditAccount>(); }
        }

        public IEnumerable<BankAccount> BankAccounts
        {
            get { return Accounts.OfType<BankAccount>(); }
        }

        private void OnBalanceChanged(object sender, EventArgs e)
        {
            // A balance was changed, need to update net worth calculation.
            RecalculateNetWorth();
        }

        private void RecalculateNetWorth()
        {
            double old = NetWorth;
            _debts = 0;
            _assets = 0;

            foreach (Account account in _accounts)
            {
                double balance = account.Balance;
                _debts += balance < 0 ? balance : 0;
                _assets += balance > 0 ? balance : 0;
            }
            if (NetWorth != old)
            {
                OnNetWorthChanged(EventArgs.Empty);
            }
        }

        protected virtual void OnNetWorthChanged(EventArgs e)
        {
            EventHandler handler = NetWorthChanged;
            if (handler != null)
            {
                handler(this, e);
            }

            NotifyPropertyChanged("NetWorth");
            NotifyPropertyChanged("Assets");
            NotifyPropertyChanged("Debts");
        }

        public double Assets { get { return _assets; } }
        public double Debts { get { return _debts; } }
        public double NetWorth
        {
            get { return _assets + _debts; }
        }
    }
}