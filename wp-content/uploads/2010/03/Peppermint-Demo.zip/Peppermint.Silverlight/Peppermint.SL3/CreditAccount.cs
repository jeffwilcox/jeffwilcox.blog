﻿// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Public License (Ms-PL).
// Please see http://go.microsoft.com/fwlink/?LinkID=131993 for details.
// All other rights reserved.

using System;

namespace Peppermint.Data
{
    public class CreditAccount : Account
    {
        /// <summary>
        /// Gets or sets the credit limit for the
        /// account.
        /// </summary>
        public double Limit
        {
            get { return _limit; }
            set
            {
                _limit = value;

                if (_limit < 0)
                {
                    throw new IndexOutOfRangeException();
                }

                OnLimitChanged(EventArgs.Empty);
            }
        }

        public event EventHandler LimitChanged;

        public CreditAccount() : this(null, CreditBrand.Unknown)
        {
        }

        public CreditAccount(string name, CreditBrand brand) : base(name)
        {
            Brand = brand;
        }

        protected virtual void OnLimitChanged(EventArgs e)
        {
            EventHandler handler = LimitChanged;
            if (handler != null)
            {
                handler(this, e);
            }

            NotifyPropertyChanged("Limit");
            NotifyPropertyChanged("AvailableCredit");
        }

        protected override void OnBalanceChanged(EventArgs e)
        {
            base.OnBalanceChanged(e);

            // Update the available credit property
            NotifyPropertyChanged("AvailableCredit");
        }

        private double _limit;

        private CreditBrand _brand;

        public double AvailableCredit
        {
            get { return _limit - Balance; }
        }

        public CreditBrand Brand
        {
            get { return _brand; }
            set
            {
                if (value != CreditBrand.AmericanExpress &&
                    value != CreditBrand.DinersClub &&
                    value != CreditBrand.Discover &&
                    value != CreditBrand.MasterCard &&
                    value != CreditBrand.Unknown &&
                    value != CreditBrand.Visa)
                {
                    throw new ArgumentException("Brand");
                }

                _brand = value;
                NotifyPropertyChanged("Brand");
            }
        }
    }
}