﻿// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Public License (Ms-PL).
// Please see http://go.microsoft.com/fwlink/?LinkID=131993 for details.
// All other rights reserved.

using System;

namespace Peppermint.Data
{
    public class BankAccount : Account
    {
        /// <summary>
        /// Backing field for the reserved cash amount. This is a required
        /// minimum balance, hold, or other amount that cannot be withdrawn
        /// from the account at this time.
        /// </summary>
        private double _reservedCash;

        public event EventHandler ReservedCashChanged;

        public BankAccount()
            : this(null)
        {
        }

        public BankAccount(string name)
            : base(name)
        {
        }

        protected override void OnBalanceChanged(EventArgs e)
        {
            base.OnBalanceChanged(e);
            NotifyPropertyChanged("AvailableCash");
        }

        protected virtual void OnReservedCashChanged(EventArgs e)
        {
            EventHandler handler = ReservedCashChanged;
            if (handler != null)
            {
                handler(this, e);
            }

            NotifyPropertyChanged("ReservedCash");
            NotifyPropertyChanged("AvailableCash");
        }

        public double ReservedCash
        {
            get { return _reservedCash; }
            set
            {
                _reservedCash = value;
                OnReservedCashChanged(EventArgs.Empty);
            }
        }

        public double AvailableCash
        {
            get { return Balance - _reservedCash; }
        }
    }
}