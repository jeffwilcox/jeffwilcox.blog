﻿// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Public License (Ms-PL).
// Please see http://go.microsoft.com/fwlink/?LinkID=131993 for details.
// All other rights reserved.

using System;
using System.Globalization;
using System.Windows.Data;

namespace Peppermint.Data
{
    public class StringFormatConverter : IValueConverter
    {
        public string DefaultParameter { get; set; }

        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            string p = parameter as string;
            if (p == null)
            {
                p = DefaultParameter;
            }
            if (!string.IsNullOrEmpty(p))
            {
                return string.Format(culture, p, value);
            }

            return value.ToString();
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return null;
        }
    }
}