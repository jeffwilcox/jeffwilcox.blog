﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Silverlight.Testing;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Peppermint.Data;

namespace HelloMix
{
    [TestClass]
    public class Tests
    {
        [TestMethod]
        public void TestMethod1()
        {
            CreditAccount ca = new CreditAccount();
            ca.Balance = 1000;
            Assert.IsTrue(ca.Balance == 1000);
        }

        [TestMethod]
        public void E_FAIL()
        {
            CreditAccount ca = new CreditAccount();
            ca.Limit = -500;
        }
    }
}