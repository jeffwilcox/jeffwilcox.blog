﻿// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Public License (Ms-PL).
// Please see http://go.microsoft.com/fwlink/?LinkID=131993 for details.
// All other rights reserved.

using System;
using System.Linq;
using System.Net;
using System.Windows.Media;
using System.Xml.Linq;
using Microsoft.Phone.Controls;
using System.Windows.Media.Imaging;
using System.Globalization;

namespace DynamicPanoramaBackgrounds.Views
{
    public partial class Bing : PhoneApplicationPage
    {
        private const string LatestPhotoUri = "LatestPhotoUri";
        private const string LastUpdated = "LastUpdated";
        private static readonly Uri PhotoImagesUri = new Uri("http://feeds.feedburner.com/bingimages");
        private static readonly TimeSpan CheckForUpdateTimeSpan = TimeSpan.FromMinutes(15);
        private Uri _photoUri;
        private DateTime? _lastUpdated;

        public Bing()
        {
            InitializeComponent();
        }

        // NOTE: Just a sample app. A real app would want to probably store
        // the most recent image in isolated storage, as well as the last
        // updated time, instead of using tombstoning for this functionality.

        public void ConsiderUpdatingBackground()
        {
            if (_photoUri == null || CacheExpired())
            {
                // WebClient is slow since its all on the UI thread but for this
                // sample its OK with me!
                WebClient wc = new WebClient();
                wc.DownloadStringCompleted += (x, xe) =>
                                                  {
                                                      // Special thanks to
                                                      // @kellabyte!
                                                      if (xe.Error == null)
                                                      {
                                                          XDocument doc = XDocument.Parse(xe.Result);
                                                          var items = doc.Element("rss")
                                                                         .Element("channel")
                                                                         .Elements("item")
                                                                         .ToList();
                                                          string countryCode = CultureInfo.CurrentUICulture.Name.ToUpperInvariant();
                                                          var urls = items
                                                              .Where(s =>
                                                                     s.Element("enclosure")
                                                                      .Attribute("url")
                                                                      .Value
                                                                      .Contains("_" + countryCode)
                                                                     ||
                                                                     s.Element("enclosure")
                                                                      .Attribute("url")
                                                                      .Value
                                                                      .Contains("_EN-US")
                                                                      )
                                                              .Select(p => 
                                                                  p.Element("enclosure")
                                                                   .Attribute("url")
                                                                   .Value)
                                                              .ToList();
                                                          if (urls.Count > 0)
                                                          {
                                                              _photoUri = new Uri(urls[0]);
                                                              _lastUpdated = DateTime.UtcNow;
                                                              SetPanoramaBackground(_photoUri);
                                                          }
                                                      }
                                                  };
                wc.DownloadStringAsync(PhotoImagesUri);
            }
        }

        private bool CacheExpired()
        {
            if (_lastUpdated.HasValue)
            {
                return (_lastUpdated.Value + CheckForUpdateTimeSpan < DateTime.UtcNow);
            }

            return true;
        }

        protected override void OnNavigatedFrom(System.Windows.Navigation.NavigationEventArgs e)
        {
            State[LatestPhotoUri] = _photoUri;
            State[LastUpdated] = _lastUpdated;

            base.OnNavigatedFrom(e);
        }

        protected override void OnNavigatedTo(System.Windows.Navigation.NavigationEventArgs e)
        {
            base.OnNavigatedTo(e);

            object o;
            if (State.TryGetValue(LatestPhotoUri, out o))
            {
                _photoUri = o as Uri;
            }

            if (State.TryGetValue(LastUpdated, out o))
            {
                _lastUpdated = (DateTime?)o;
            }

            if (_photoUri != null)
            {
                SetPanoramaBackground(_photoUri);
            }

            ConsiderUpdatingBackground();
        }

        private void SetPanoramaBackground(Uri uri)
        {
            pano1.Background = new ImageBrush
                                   {
                                        ImageSource = new BitmapImage(uri),
                                   };

        }
    }
}