﻿// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Public License (Ms-PL).
// Please see http://go.microsoft.com/fwlink/?LinkID=131993 for details.
// All other rights reserved.

using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Microsoft.Phone.Controls;

namespace DynamicPanoramaBackgrounds.Views
{
    public partial class BuiltInImages : PhoneApplicationPage
    {
        private const string LatestPhotoUri = "LatestPhotoUri";
        private Uri _photoUri;

        public BuiltInImages()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            var s = (Button) sender;
            string su = (string) s.Tag;
            _photoUri = new Uri(su, UriKind.Relative);
            SetPanoramaBackground(_photoUri);
        }

        protected override void OnNavigatedFrom(System.Windows.Navigation.NavigationEventArgs e)
        {
            State[LatestPhotoUri] = _photoUri;

            base.OnNavigatedFrom(e);
        }

        protected override void OnNavigatedTo(System.Windows.Navigation.NavigationEventArgs e)
        {
            base.OnNavigatedTo(e);

            object o;
            if (State.TryGetValue(LatestPhotoUri, out o))
            {
                _photoUri = o as Uri;
            }

            if (_photoUri != null)
            {
                SetPanoramaBackground(_photoUri);
            }
        }

        private void SetPanoramaBackground(Uri uri)
        {
            pano1.Background = new ImageBrush
            {
                ImageSource = new BitmapImage(uri),
            };

        }
    }
}