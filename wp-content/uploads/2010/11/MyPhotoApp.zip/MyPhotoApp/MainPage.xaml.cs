﻿// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Public License (Ms-PL).
// Please see http://go.microsoft.com/fwlink/?LinkID=131993 for details.
// All other rights reserved.

using System;
using System.Windows;
using Microsoft.Phone.Controls;
using MyPhotoApp.Flickr;

namespace MyPhotoApp
{
    public partial class MainPage : PhoneApplicationPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void OnButtonClick(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri(
                string.Format(
                "/Views/SlideshowPage.xaml?id={0}",
                ((Photoset)SetList.SelectedItem).Id),
                UriKind.Relative));
        }
    }
}