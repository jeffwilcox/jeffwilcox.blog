﻿// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Public License (Ms-PL).
// Please see http://go.microsoft.com/fwlink/?LinkID=131993 for details.
// All other rights reserved.

namespace MyPhotoApp.Flickr
{
    using System;
    using System.IO;
    using System.Net;

    /// <summary>
    /// Simple implementation of a helpful web client wrapper that does a 
    /// majority of its work on the background thread as opposed to the standard
    /// WebClient implementation that favors the user interface thread for all
    /// of its work.
    /// </summary>
    public class FastWebClient
    {
        /// <summary>
        /// The HTTP web request instance.
        /// </summary>
        private HttpWebRequest _webRequest;

        /// <summary>
        /// Download string completed event.
        /// </summary>
        public event EventHandler<DownloadStringCompletedEventArgs> DownloadStringCompleted;

        /// <summary>
        /// Begins an asynchronous download of a string from a URI resource.
        /// </summary>
        /// <param name="uri">The URI to download from.</param>
        public void DownloadStringAsync(Uri uri)
        {
            _webRequest = (HttpWebRequest) WebRequest.Create(uri);
            _webRequest.AllowReadStreamBuffering = true;
            _webRequest.BeginGetResponse(BeginResponse, null);
        }

        private void BeginResponse(IAsyncResult ar)
        {
            string responseStr = null;
            var handler = DownloadStringCompleted;

            try
            {
                using (WebResponse webResponse = _webRequest.EndGetResponse(ar))
                {
                    using (var sr = new StreamReader(webResponse.GetResponseStream()))
                    {
                        responseStr = sr.ReadToEnd();
                    }
                }
            }
            catch (Exception e)
            {
                if (handler != null)
                {
                    handler(this, new DownloadStringCompletedEventArgs(null, e));
                }

                return;
            }

            if (handler != null)
            {
                Exception error = null;
                string result = responseStr;
                if (string.IsNullOrEmpty(responseStr))
                {
                    error = new Exception("Nothing came back from the server-side.");
                }
                handler(this, new DownloadStringCompletedEventArgs(result, error));
            }
        }
    }
}
