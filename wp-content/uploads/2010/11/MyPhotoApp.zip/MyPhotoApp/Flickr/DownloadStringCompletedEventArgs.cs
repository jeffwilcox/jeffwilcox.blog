﻿namespace MyPhotoApp.Flickr
{
    using System;
    using System.ComponentModel;

    public class DownloadStringCompletedEventArgs : AsyncCompletedEventArgs
    {
        public DownloadStringCompletedEventArgs(string result,
                                                Exception ex)
            : base(ex, false, null)
        {
            Result = result;
        }

        public string Result { get; private set; }
    }
}