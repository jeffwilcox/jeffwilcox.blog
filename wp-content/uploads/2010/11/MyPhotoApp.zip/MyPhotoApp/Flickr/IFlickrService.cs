﻿// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Public License (Ms-PL).
// Please see http://go.microsoft.com/fwlink/?LinkID=131993 for details.
// All other rights reserved.

using System;
using System.Collections.Generic;

namespace MyPhotoApp.Flickr
{
    /// <summary>
    /// A simple Flickr service interface. Just a tiny subset.
    /// </summary>
    public interface IFlickrService
    {
        /// <summary>
        /// Loads the photos in a photoset.
        /// </summary>
        /// <param name="photosetId">The photoset ID.</param>
        /// <param name="photosCallback">The callback method.</param>
        void LoadPhotoset(string photosetId, Action<IEnumerable<Photo>> photosCallback);

        /// <summary>
        /// Loads the photosets that a user has created.
        /// </summary>
        /// <param name="userId">The Flickr user ID.</param>
        /// <param name="photosetsCallback">The callback method.</param>
        void LoadPhotosets(string userId, Action<IEnumerable<Photoset>> photosetsCallback);
    }
}
