﻿// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Public License (Ms-PL).
// Please see http://go.microsoft.com/fwlink/?LinkID=131993 for details.
// All other rights reserved.

 // The CodePlex site at http://json.codeplex.com/ offers the excellent JSON
// capabilities used in this project.

namespace MyPhotoApp.Flickr
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using Newtonsoft.Json.Linq;

    public class FlickrService : IFlickrService
    {
        // TODO: INSERT YOUR API KEY!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        /// <summary>
        /// The API key for connecting to the Flickr REST web service APIs.
        /// </summary>
        private const string FlickrApiKey = "<API Key>";

        /// <summary>
        /// The endpoint for REST calls.
        /// </summary>
        private const string FlickrEndpoint = "http://api.flickr.com/services/rest/";

        #region IFlickrService Members

        /// <summary>
        /// Loads the photosets for a given Flickr user ID.
        /// </summary>
        /// <param name="userId">The user ID whose sets you want to retrieve.</param>
        /// <param name="photosetsCallback">The callback that will contain the
        /// photoset data.</param>
        public void LoadPhotosets(string userId,
                                  Action<IEnumerable<Photoset>> photosetsCallback)
        {
            var wc = new FastWebClient();
            wc.DownloadStringCompleted += (s,
                                           e) =>
                {
                    var sets = new List<Photoset>();
                    if (e.Error == null)
                    {
                        JObject o = JObject.Parse(ProcessFlickrJson(e.Result));
                        var result = (string) o["stat"];
                        if (result == "ok")
                        {
                            var ps = (JObject) o["photosets"];
                            var pics = (JArray) ps["photoset"];
                            sets.AddRange(from JObject pic in pics
                                          select new Photoset
                                              {
                                                  Id = (string) pic["id"],
                                                  Title = (string) ((JObject) pic["title"])["_content"],
                                                  Description = (string) ((JObject) pic["description"])["_content"]
                                              });
                        }
                    }
                    photosetsCallback(sets);
                };
            wc.DownloadStringAsync(BuildFlickrUri("flickr.photosets.getList",
                                                  "user_id", userId));
        }

        /// <summary>
        /// Loads a photoset by returning all the photos in it.
        /// </summary>
        /// <param name="id">The photoset ID.</param>
        /// <param name="photosCallback">The callback that will take an
        /// enumerable set of the photos in the set.</param>
        public void LoadPhotoset(string id,
                                 Action<IEnumerable<Photo>> photosCallback)
        {
            var wc = new FastWebClient();
            wc.DownloadStringCompleted += (s,
                                           e) =>
                {
                    var photos = new List<Photo>();
                    if (e.Error == null)
                    {
                        JObject o = JObject.Parse(ProcessFlickrJson(e.Result));
                        var result = (string) o["stat"];
                        if (result == "ok")
                        {
                            var ps = (JObject) o["photoset"];
                            var pics = (JArray) ps["photo"];
                            photos.AddRange(from JObject pic in pics
                                            select new Photo
                                                {
                                                    Id = (string) pic["id"],
                                                    Title = (string) pic["title"],
                                                    ImageUrl = (string) pic["url_m"],
                                                });
                        }
                    }
                    photosCallback(photos);
                };
            wc.DownloadStringAsync(BuildFlickrUri("flickr.photosets.getPhotos",
                                                  "photoset_id", id,
                                                  "extras", "url_m"));
        }

        #endregion

        /// <summary>
        /// Builds a simple Flickr REST Uri using a set of components.
        /// </summary>
        /// <param name="method">The named Flickr method to call.</param>
        /// <param name="components">An even-numbered array of the set of
        /// key/value properties to pass to the method as parameters.</param>
        /// <returns>Returns a Flickr URI.</returns>
        private static Uri BuildFlickrUri(string method,
                                          params string[] components)
        {
            var d = new Dictionary<string, string>();
            d["method"] = method;
            d["api_key"] = FlickrApiKey;
            d["format"] = "json";

            if (components != null && components.Length > 0)
            {
                // Can overrun if not even number. Messy code!
                for (int i = 0; i < components.Length; i += 2)
                {
                    d[components[i]] = components[i + 1];
                }
            }

            var sb = new StringBuilder();
            sb.Append(FlickrEndpoint);
            sb.Append("?");

            foreach (var c in d)
            {
                sb.Append(c.Key);
                sb.Append("=");
                sb.Append(c.Value);
                sb.Append("&");
            }
            // Trim the last ampersand.
            sb.Remove(sb.Length - 1, 1);

            return new Uri(sb.ToString(), UriKind.Absolute);
        }

        /// <summary>
        /// Strips off the JSON from a Flickr request so that the JSON.net
        /// library can properly work with the data.
        /// </summary>
        /// <param name="json">The JSON string.</param>
        /// <returns>Returns a slightly trimmed JSON string.</returns>
        private static string ProcessFlickrJson(string json)
        {
            const string tk = "jsonFlickrApi(";
            return json.Substring(tk.Length, json.Length - tk.Length);
        }
    }
}
