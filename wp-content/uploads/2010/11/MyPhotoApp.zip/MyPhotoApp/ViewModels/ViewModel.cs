﻿// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Public License (Ms-PL).
// Please see http://go.microsoft.com/fwlink/?LinkID=131993 for details.
// All other rights reserved.

using System;
using System.ComponentModel;
using System.Windows;

namespace MyPhotoApp.ViewModels
{
    // This code is good enough for a conference.
    // But if it was awesome, it would also:
    // - Store a single event arg instance per property
    // - Ensure proper smart dispatching
    // - Have comments
    // :-)

    public abstract class ViewModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            var pc = PropertyChanged;
            if (pc != null)
            {
                pc(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        protected void Dispatch(Action action)
        {
            Deployment.Current.Dispatcher.BeginInvoke(action);
        }
    }
}
