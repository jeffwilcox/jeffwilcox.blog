﻿// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Public License (Ms-PL).
// Please see http://go.microsoft.com/fwlink/?LinkID=131993 for details.
// All other rights reserved.

namespace MyPhotoApp.ViewModels
{
    using System.Collections.Generic;
    using Flickr;

    public class SlideshowViewModel : ViewModel
    {
        private readonly IFlickrService _flickr;
        private bool _isLoading;
        private IEnumerable<Photo> _photos;

        public SlideshowViewModel()
            : this(new FlickrService())
        {
        }

        public SlideshowViewModel(IFlickrService flickrService)
        {
            _flickr = flickrService;
        }

        public bool IsLoading
        {
            get { return _isLoading; }
            private set
            {
                _isLoading = value;
                RaisePropertyChanged("IsLoading");
            }
        }

        public IEnumerable<Photo> Photos
        {
            get { return _photos; }
            set
            {
                _photos = value;
                RaisePropertyChanged("Photos");
            }
        }

        public void LoadPhotos(string photosetId)
        {
            IsLoading = true;
            _flickr.LoadPhotoset(photosetId, photos => Dispatch(() =>
                {
                    if (photos != null)
                    {
                        Photos = photos;
                    }
                    IsLoading = false;
                }));
        }
    }
}
