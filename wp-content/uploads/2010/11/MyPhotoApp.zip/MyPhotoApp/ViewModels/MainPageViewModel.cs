﻿// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Public License (Ms-PL).
// Please see http://go.microsoft.com/fwlink/?LinkID=131993 for details.
// All other rights reserved.

namespace MyPhotoApp.ViewModels
{
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Linq;
    using Flickr;

    public class MainPageViewModel : ViewModel
    {
        private readonly IFlickrService _flickr;

        private bool _isLoading;

        private IEnumerable<Photoset> _sets;

        private string _title;

        public MainPageViewModel() : this(new FlickrService())
        {
        }

        public MainPageViewModel(IFlickrService flickr)
        {
            Title = "Øredev";
            _flickr = flickr;
            if (!DesignerProperties.IsInDesignTool)
            {
                LoadPhotosets();
            }
        }

        public bool IsLoading
        {
            get { return _isLoading; }
            set
            {
                _isLoading = value;
                RaisePropertyChanged("IsLoading");
            }
        }

        public IEnumerable<Photoset> Photosets
        {
            get { return _sets; }
            set
            {
                _sets = value;
                RaisePropertyChanged("Photosets");
            }
        }

        public string Title
        {
            get { return _title; }
            set
            {
                _title = value;
                RaisePropertyChanged("Title");
            }
        }

        private void LoadPhotosets()
        {
            IsLoading = true;
            _flickr.LoadPhotosets(
                // This is my hard-coded Flickr user ID (jeffwilcox). A real app 
                // would store this kind of thing in isolated storage after
                // asking it from the user in a friendly manner.
                "66638708@N00",
                sets => Dispatch(() =>
                    {
                        if (sets != null)
                        {
                            Photosets = sets.Take(4);
                        }
                        IsLoading = false;
                    }));
        }
    }
}
