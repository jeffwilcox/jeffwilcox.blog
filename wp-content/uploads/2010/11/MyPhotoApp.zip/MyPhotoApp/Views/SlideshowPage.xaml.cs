﻿// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Public License (Ms-PL).
// Please see http://go.microsoft.com/fwlink/?LinkID=131993 for details.
// All other rights reserved.

namespace MyPhotoApp.Views
{
    using System.Windows.Navigation;
    using Microsoft.Phone.Controls;
    using ViewModels;

    public partial class SlideshowPage : PhoneApplicationPage
    {
        public SlideshowPage()
        {
            InitializeComponent();
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            base.OnNavigatedTo(e);

            var context = DataContext as SlideshowViewModel;
            if (context != null)
            {
                string id;
                if (NavigationContext.QueryString.TryGetValue("id", out id))
                {
                    context.LoadPhotos(id);
                }
            }
        }
    }
}
